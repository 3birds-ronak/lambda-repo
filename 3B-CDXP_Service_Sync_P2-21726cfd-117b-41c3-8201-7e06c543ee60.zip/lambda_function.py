import json
import psycopg2
import datetime

def lambda_handler(event, context):
    
    conn = psycopg2.connect(
        database="3B-CDXP",
        user="mauticanalytics",
        password="Mvkor!kens",
        host="analytics-mautics.chxqqwn3nfwz.us-east-2.rds.amazonaws.com",
        port='5432'
    )

    cur1 = conn.cursor()
        
    for i in event:
        row = i['data']
        
        client_id = row[0]
        event_nk = row[1]
        event_date = None if row[2] == None else datetime.datetime.strptime(row[2], "%Y-%m-%d").date()
        event_type = row[3]
        event_properties = {
            "CustomerNumber": row[4],
            "FirstName": row[5],
            "LastName": row[6],
            "Address": row[7],
            "ZIPCode": row[8],
            "EmailAddress": row[9],
            "EmailDomain": row[10],
            
            "VIN": row[11],
            "Make": row[12],
            "Model": row[13],
            "Year": row[14],
            "Type": row[15],
            
            "OpenDate": row[16],
            "ServiceAdvisorName": row[17],
            "ROAmount": row[18],
            "ClosedDate": row[19],
            
            "WPROTotal": row[20],
            "CPROTotal": row[21],
            "CPPartsCost": row[22],
            "CPLaborCost": row[23],
            "CPMiscCost": row[24],
            "WPPartsCost": row[25],
            "WPLaborCost": row[26],
            "WPMiscCost": row[27],
            
            "StockType": row[28],
            "HasDeclinedService": row[29],
            "Department": row[30]
        }
        
        ##############
        
        query1 = f"""
            CALL marketing.upsert_event(
                %s, %s, %s, %s, %s
            )
            """
        
        cur1.execute(query1, (client_id, event_nk, event_date, event_type, json.dumps(event_properties)))

        conn.commit()
    
    conn.close()
    
    return {
        'statusCode': 200
    }
