import psycopg2
import json
import boto3
import requests
import datetime
import urllib.parse

def lambda_handler(event, context):
    
    conn = None
    try:
        conn = psycopg2.connect(
            database="3B-CDXP",
            user="mauticanalytics",
            password="Mvkor!kens",
            host="analytics-mautics.chxqqwn3nfwz.us-east-2.rds.amazonaws.com",
            port='5432'
        )
    
        cur1 = conn.cursor()
    
        engagement_id = event['engagement_id']
        event_type = event['event_type']
        event_data = event['event_data']
        campaign_source_id = 0
        contact_source_id = 0
        message_source_id = 0
        instance_id = 0
        unsubcribe_link = ''
        is_process = 0
        contact_emailid = ''
        
        for header in event_data['mail']['headers']:
            if header['name'] == 'X-CAMPAIGN-ID':
                campaign_source_id = int(header['value'])
            elif header['name'] == '3B-CONTACT-ID':
                contact_source_id = int(header['value'])
            elif header['name'] == 'X-EMAIL-ID':
                message_source_id = int(header['value'])
            elif header['name'] == 'List-Unsubscribe':
                unsubcribe_link = header['value']
            elif header['name'] == 'To':
                contact_emailid = header['value']
                
        if campaign_source_id > 0 and (contact_source_id > 0 or contact_emailid != '') and message_source_id > 0:
            
            if len(event_data['mail']['tags']['ses:from-domain']) > 0:
                query1 = f"""
                    SELECT i.instance_id, i.instance_data
                    FROM marketing.instance i
                    WHERE i.instance_data @> %s
                    """
                cur1.execute(query1, [json.dumps({"email_domain":[event_data['mail']['tags']['ses:from-domain'][0]]})])
                
                instance = cur1.fetchone()
                                    
                if instance != None and instance[0] > 0:
                    instance_id = instance[0]
                    
                    if contact_emailid != '':  #contact_source_id == 0
                        e1 = contact_emailid.split("@")
                        e2 = e1[0].split("+")
                        
                        if len(e2) > 1 and e2[len(e2)-1].isnumeric():
                            contact_source_id = e2[len(e2)-1]
                        else:
                            r = requests.get(instance[1]['instance_url'] + "/api/contacts?search=" + urllib.parse.quote(contact_emailid) + "&limit=1", auth=(instance[1]['admin_username'], instance[1]['admin_password']))
                            json_contact = r.json()
                            
                            if r.status_code == 200 and len(json_contact['contacts']) > 0:
                                cnts = list(json_contact['contacts'].keys())
                                contact_source_id = cnts[0]
                    
                    print('instance_id'+str(instance_id))
                    print('campaign_source_id'+str(campaign_source_id))
                    print('contact_source_id'+str(contact_source_id))
                    print('message_source_id'+str(message_source_id))
            
                    query1 = f"""
                        SELECT c.contact_id, c.campaign_id
                        FROM marketing.contact c
                        JOIN marketing.campaign cmp ON cmp.campaign_id = c.campaign_id AND cmp.campaign_source_id = %s AND cmp.instance_id = %s
                        JOIN marketing.message m ON m.message_id = c.message_id AND m.message_source_id = %s AND m.instance_id = %s
                        WHERE c.contact_source_id = %s
                        ORDER BY c.contact_id DESC
                        LIMIT 1
                        """
                    cur1.execute(query1, [campaign_source_id, instance_id, message_source_id, instance_id, contact_source_id])
                    
                    contacts = cur1.fetchone()
                                    
                    if contacts != None and contacts[0] > 0:
                        contact_id = contacts[0]
                        campaign_id = contacts[1]
                        event_date = event_data['mail']['timestamp']
                        
                        if event_type == 'Delivery':
                            event_date = event_data['delivery']['timestamp']
                            query1 = f"""
                                UPDATE marketing.contact
                                SET delivered = true, updated = now()
                                WHERE contact_id = %s
                                """
                            cur1.execute(query1, [contact_id])
                        elif event_type == 'Complaint':
                            event_date = event_data['complaint']['timestamp']
                            query1 = f"""
                                UPDATE marketing.contact
                                SET complained = true, updated = now()
                                WHERE contact_id = %s
                                """
                            cur1.execute(query1, [contact_id])
                        elif event_type == 'Open':
                            event_date = event_data['open']['timestamp']
                            query1 = f"""
                                UPDATE marketing.contact
                                SET opened = true, updated = now()
                                WHERE contact_id = %s
                                """
                            cur1.execute(query1, [contact_id])
                        elif event_type == 'Click':  
                            event_date = event_data['click']['timestamp']
                            if "<" + event_data['click']['link'] + ">" == unsubcribe_link:
                                query1 = f"""
                                    UPDATE marketing.contact
                                    SET unsubscribed = true, updated = now()
                                    WHERE contact_id = %s
                                    """
                                cur1.execute(query1, [contact_id])
                            else:
                                query1 = f"""
                                    UPDATE marketing.contact
                                    SET clicked = true, updated = now()
                                    WHERE contact_id = %s
                                    """
                                cur1.execute(query1, [contact_id])
                        elif event_type == 'Bounce':  
                            event_date = event_data['bounce']['timestamp']
                                
                        query1 = f"""
                            UPDATE marketing.engagement
                            SET contact_id = %s, campaign_id = %s, event_date = %s, is_process = true
                            WHERE engagement_id = %s
                            """
                        cur1.execute(query1, [contact_id, campaign_id, event_date, engagement_id])
                        
                        is_process = 1
        
        #if is_process == 0:
        #    query1 = f"""
        #        UPDATE marketing.engagement
        #        SET is_process = true
        #        WHERE engagement_id = %s
        #        """
        #    cur1.execute(query1, [engagement_id])
        
        conn.commit()
        
    except Exception as e:
        print('Error', e)
        raise e
    finally:
        if conn is not None:
            conn.close()
        print('Finally End')
    
    return {
        'statusCode': 200,
        'body': 'Success'
    }

if __name__ == "__main__":
    lambda_handler('', '')