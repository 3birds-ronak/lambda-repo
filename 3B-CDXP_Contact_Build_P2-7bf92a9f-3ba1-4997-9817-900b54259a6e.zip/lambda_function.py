import psycopg2
import json
import boto3
import requests
import datetime
client = boto3.client('lambda', region_name='us-east-2')

def lambda_handler(event, context):
    
    conn = None
    try:
        conn = psycopg2.connect(
            database="3B-CDXP",
            user="mauticanalytics",
            password="Mvkor!kens",
            host="analytics-mautics.chxqqwn3nfwz.us-east-2.rds.amazonaws.com",
            port='5432'
        )
    
        cur1 = conn.cursor()
        
        campaign_id = event['campaign_id']
        campaign_source_id = event['campaign_source_id']
        instance_id = event['instance_id']
        client_id = event['client_id']
            
        contact_source_id = event['contact_source_id']
        created = event['created']
        instance_url = event['instance_url']
        admin_username = event['admin_username']
        admin_password = event['admin_password']
        
        start_date = str(datetime.date.today()-datetime.timedelta(1)) + " 00:00:00"
        end_date = str(datetime.date.today()-datetime.timedelta(1)) + " 23:59:59"
        
        r = requests.get(instance_url + "/api/contacts/" + str(contact_source_id) + "/activity?filters[includeEvents][0]=campaign.event&filters[dateFrom]=" + start_date + "&filters[dateTo]=" + end_date, auth=(admin_username, admin_password))
        
        if 'json' in r.headers.get('Content-Type'):
            json_cnt_activities = r.json()
            print(json_cnt_activities)
            
            if r.status_code == 200 and len(json_cnt_activities['events']) > 0 :
                
                r = requests.get(instance_url + "/api/contacts/" + str(contact_source_id), auth=(admin_username, admin_password))
                json_cnt_dtl = r.json()
                
                if r.status_code == 200:
                    first_name = json_cnt_dtl['contact']['fields']['all']['firstname']
                    last_name = json_cnt_dtl['contact']['fields']['all']['lastname']
                    vin = None
                    client_id = json_cnt_dtl['contact']['fields']['all']['c_client_id'] if client_id == None or client_id == '' else client_id
                    make = json_cnt_dtl['contact']['fields']['all']['c_make']
                    model = json_cnt_dtl['contact']['fields']['all']['c_model']
                    year = json_cnt_dtl['contact']['fields']['all']['c_year']
                    address = json_cnt_dtl['contact']['fields']['all']['address1']
                    city = json_cnt_dtl['contact']['fields']['all']['city']
                    state = json_cnt_dtl['contact']['fields']['all']['state']
                    zip = json_cnt_dtl['contact']['fields']['all']['zipcode']
                    email_address = json_cnt_dtl['contact']['fields']['all']['email']
                    is_email = False if json_cnt_dtl['contact']['fields']['all']['c_eligible_email'] == None else bool(json_cnt_dtl['contact']['fields']['all']['c_eligible_email']) 
                    is_direct_mail = False if json_cnt_dtl['contact']['fields']['all']['c_eligible_mail'] == None else bool(json_cnt_dtl['contact']['fields']['all']['c_eligible_mail']) 
                    is_sms = False if json_cnt_dtl['contact']['fields']['all']['c_eligible_sms'] == None else bool(json_cnt_dtl['contact']['fields']['all']['c_eligible_sms']) 
                    contact_type = json_cnt_dtl['contact']['fields']['all']['c_contact_type']
                    
                    for event in json_cnt_activities['events'] :
                        if event['details']['log']['campaign_id'] == str(campaign_source_id) and event['details']['log']['type'] == 'email.send' and event['details']['log']['channel'] == 'email':
                            message_source_id = event['details']['log']['channel_id']
                            date_sent = datetime.datetime.fromisoformat(event['details']['log']['dateTriggered'])
                            date_sent = date_sent.strftime("%Y-%m-%d")
                            event_name = event['details']['log']['event_name']
                            
                            query1 = f"""
                                SELECT m.message_id
                                FROM marketing.message m
                                JOIN marketing.instance i on i.instance_id = m.instance_id AND i.instance_type = 'Mautic'
                                WHERE m.message_source_id = %s"""
                            
                            cur1.execute(query1, [message_source_id])
                            message = cur1.fetchone()
                            
                            if message != None and message[0] > 0:
                                message_id = message[0]
                                
                                query1 = f"""
                                    CALL marketing.upsert_contact(
                                        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
                                    )
                                    """
                                
                                cur1.execute(query1, (campaign_id, message_id, contact_source_id, first_name, last_name, vin, make, model, year, address, city, state, zip, email_address, is_email, is_direct_mail, is_sms, date_sent, created, json.dumps(event), event_name, client_id, instance_id, contact_type))
                
                                conn.commit()
        
    except Exception as e:
        print('Error', e)
        raise e
    finally:
        if conn is not None:
            print('Inside Conn', conn)
            conn.close()
            print('conn closed', conn)
        print('Finally End')

    return {
        'statusCode': 200,
        'body': 'Success'
    }

if __name__ == "__main__":
    lambda_handler('', '')