import json
import pyodbc
import boto3
client = boto3.client('lambda', region_name='us-east-2')

def lambda_handler(event, context):
    server = '10.254.210.32' 
    database = 'EDW_target' 
    username = 'helium' 
    password = 'heliumpw' 
    clientid = event['client_id']
    #clientid = 140585
    
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    cur = conn.cursor()
    cur.execute(f"""
        SELECT -- TOP 10
            t.clientid as client_id
            ,fs.[AppointmentNumber] as event_nk 
            ,CAST(t.[TransactionDate] AS DATE) as event_date
            ,'appointment' as event_type
            ,fs.[CustomerNumber] as CustomerNumber
            ,fn.FirstName
            ,fn.LastName
            ,da.Address
            ,da.ZIPCode
            ,de.EmailAddress
            ,de.EmailDomain
            ,dv.VIN
            ,fv.Make
            ,fv.Model
            ,fv.Year
            ,fv.Type
            ,AppointmentDate 
            ,AppointmentTime 
            ,AppointmentCreateDate 
            ,RONumber 
            ,LastROMiles 
            ,LastRODate 
            ,PromiseDate 
            ,PromiseTime 
            ,Cause 
            ,Complaint 
            ,Comment 
            ,OperationCode 
            ,OperationCodeDescription 
            ,RecommendedOperationCode 
            ,RecommendedOperationCodeDescription 
            ,ServiceAdvisorName 
            ,ServiceAdvisorNumber 
            ,SaleType 
            ,WaitingFlag 
            ,LoanerFlag 
            ,AlternateTransportation 
            ,EstimateTime 
            ,EstimateAmount 
            ,TagNumber 
            ,ModelNumber 
            ,AppointmentMileage
            ,[Description] 
            ,ExteriorColor 
            ,StockNumber 
            ,Transmission 
            ,[Trim] 
            ,LicensePlateNumber 
            ,DeliveryDate
            ,DeliveryMileage
            ,InServiceDate
            ,VINExplosionYear 
            ,VINExplosionMake 
            ,VINExplosionModel 
            ,VINExplosionTrim 
            ,VINExplosionTransmissionType 
            ,VINExplosionFuelType 
            ,VINExplosionEngineSize 
            ,VINExplosionGVWRange 
            ,HomePhone 
            ,CellPhone 
            ,WorkPhone 
            ,BirthDate
            ,IndividualBusinessFlag 
            ,OptOut 
            ,BlockEmail 
            ,BlockMail 
            ,BlockPhone 
            ,CustomerCreateDate
            ,CustomerLastActivityDate
        
        FROM [dbo].[DMS_Fact_Appointment] fs with (nolock, readuncommitted)
        	INNER JOIN [dbo].[DMS_Dim_Transactions] t  with (nolock, readuncommitted) on
        		fs.[EDW_DMS_Transaction_ID] = t.[EDW_DMS_Transaction_ID]
        	INNER JOIN [dbo].[DMS_Fact_Vehicles] fv  with (nolock, readuncommitted) on
        		t.[EDW_DMS_Transaction_ID] = fv.[EDW_DMS_Transaction_ID]
        	INNER JOIN [dbo].[DMS_Dim_Vehicles] dv  with (nolock, readuncommitted) on
        		fv.[EDW_DMS_Vehicle_ID] = dv.[EDW_DMS_Vehicle_ID]
        	INNER JOIN [dbo].[DMS_Fact_EmailAddresses] fe  with (nolock, readuncommitted) on
        		t.EDW_DMS_Transaction_ID = fe.EDW_DMS_Transaction_ID and
        		t.[EDW_DMS_Customer_ID] = fe.[EDW_DMS_Customer_ID] 
        	INNER JOIN [dbo].[DMS_Dim_EmailAddresses] de  with (nolock, readuncommitted) on
        		fe.EDW_DMS_EmailAddress_ID = de.EDW_DMS_EmailAddress_ID
        	INNER JOIN [dbo].[DMS_Fact_Names] fn  with (nolock, readuncommitted) on
        		t.EDW_DMS_Transaction_ID = fn.EDW_DMS_Transaction_ID and
        		t.[EDW_DMS_Customer_ID] = fn.[EDW_DMS_Customer_ID] 
        	INNER JOIN dbo.[DMS_Fact_Addresses] fa  with (nolock, readuncommitted) on
        		t.[EDW_DMS_Transaction_ID] = fa.[EDW_DMS_Transaction_ID] and
        		t.[EDW_DMS_Customer_ID] = fa.[EDW_DMS_Customer_ID] 
        	INNER JOIN [dbo].[DMS_Dim_Addresses] da  with (nolock, readuncommitted) on
        		fa.[EDW_DMS_Address_ID] = da.EDW_DMS_Address_ID
            
        WHERE t.ClientID = {clientid}

        """
    )
    
    array_msg_body = []
    counter = 0
    
    for row in cur:
        row[2] = None if row[2] == None else str(row[2])
        row[16] = None if row[16] == None else str(row[16])
        row[17] = None if row[17] == None else str(row[17])
        row[18] = None if row[18] == None else str(row[18])
        row[21] = None if row[21] == None else str(row[21])
        row[22] = None if row[22] == None else str(row[22])
        row[23] = None if row[23] == None else str(row[23])
        row[48] = None if row[48] == None else str(row[48])
        row[50] = None if row[50] == None else str(row[50])
        row[62] = None if row[62] == None else str(row[62])
        row[68] = None if row[68] == None else str(row[68])
        row[69] = None if row[69] == None else str(row[69])
        
        row[20] = None if row[20] == None else float(row[20])
        row[38] = None if row[38] == None else float(row[38])
        row[41] = None if row[41] == None else float(row[41])
        row[49] = None if row[49] == None else float(row[49])
    
        
        msg_body = {
        	"data": list(row)
        }
        
        array_msg_body.append(msg_body)
        counter += 1
        
        if counter % 50 == 0:
            res = client.invoke(
                FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:3B-CDXP_Appointment_Sync_P2',
                InvocationType = 'Event',
                Payload = json.dumps(array_msg_body)
            )
            counter = 0
            array_msg_body = []
    
    if len(array_msg_body) > 0:
        res = client.invoke(
            FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:3B-CDXP_Appointment_Sync_P2',
            InvocationType = 'Event',
            Payload = json.dumps(array_msg_body)
        )
        
    conn.close()
    
    return {
        'statusCode': 200
    }
        
    
    
