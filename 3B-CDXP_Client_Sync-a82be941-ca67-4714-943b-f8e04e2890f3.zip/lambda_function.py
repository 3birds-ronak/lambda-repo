import json
import pyodbc
import psycopg2

def lambda_handler(event, context):
    server = '10.254.210.10' 
    database = 'Lift' 
    username = 'helium' 
    password = 'heliumpw' 
    
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    cur = conn.cursor()
    cur.execute(f"""
        with client_mappings as (
            SELECT
            	ls.clientid,
            	
            	max(cd.streetaddress1) as address_1,
            	max(cd.city) as city,
            	max(cd.state) as state ,
            	max(cd.PostalCode) as zip_code,
            	max(cd.CountryCode) as country,
            	max(c.clientname) as client_name,
                max(g.Name) as client_group,
            	MAX(CASE WHEN code = '[oem]' THEN case when cast(value as varchar(500)) not in ('#', 'x', 'oem', '[oem]') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS client_oem	
            FROM
             
            	[Lift].[dbo].[Lift_Site_Shortcode_Overrides]  oc
            	inner join [Lift].[dbo].[lift_sites] ls on
            		oc.SiteId = ls.siteid 
            	inner join [ClientDB].[dbo].[Clients] c on
            		ls.ClientId = c.ClientId
            	inner join [ClientDB].[dbo].[ClientDetails] cd on
            		ls.ClientId = cd.ClientId
                inner join [ClientDB].[dbo].[ClientGroupMemberships] cgm on
                    cgm.ClientId = c.ClientID and cgm.GroupID = 541
                inner join [ClientDB].[dbo].[Groups] g on
                    g.GroupID = cgm.GroupID
            GROUP BY 
            	ls.clientid
            )
            
            select * from client_mappings

        """
    )
    
    conn1 = psycopg2.connect(
        database="3B-CDXP",
        user="mauticanalytics",
        password="Mvkor!kens",
        host="analytics-mautics.chxqqwn3nfwz.us-east-2.rds.amazonaws.com",
        port='5432'
    )

    cur1 = conn1.cursor()
    
    for row in cur:
        client_id = row[0]
        address = row[1]
        city = row[2]
        state = row[3]
        zipcode = row[4]
        country = row[5]
        client_name = row[6]
        client_group = row[7]
        client_oem = row[8]
        
        query1 = f"""
            CALL marketing.upsert_client(
                %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
            """
        
        cur1.execute(query1, (client_id, client_name, address, city, state, zipcode, country, client_oem, client_group))

        conn1.commit()
        
    conn1.close()
    conn.close()
    
    return {
        'statusCode': 200
    }
        
    
    
