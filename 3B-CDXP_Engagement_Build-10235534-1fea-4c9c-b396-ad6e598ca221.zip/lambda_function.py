import psycopg2
import json
import boto3
import requests

def lambda_handler(event, context):

    conn = None
    try:
        conn = psycopg2.connect(
            database="3B-CDXP",
            user="mauticanalytics",
            password="Mvkor!kens",
            host="analytics-mautics.chxqqwn3nfwz.us-east-2.rds.amazonaws.com",
            port='5432'
        )
        
        cur = conn.cursor()
        
        for i in event['Records']:
            event_data = json.loads(i['Sns']['Message'])
            event_type = event_data['eventType']
            print(event_data)
            
            query1 = f"""
                INSERT INTO marketing.engagement(event_type, event_data)
                	VALUES (%s, %s)
                """
            
            cur.execute(query1, (event_type, json.dumps(event_data)))    
            
        conn.commit()

    except Exception as e:
        print('Error', e)
        raise e
    finally:
        if conn is not None:
            print('Inside Conn', conn)
            conn.close()
            print('conn closed', conn)
        print('Finally End')

    return {
        'statusCode': 200,
        'body': 'Success'
    }

if __name__ == "__main__":
    lambda_handler('', '')