import json
import boto3

def lambda_handler(event, context):
    session = boto3.Session()
    
    sqs_client = session.client(
        service_name='sqs',
        endpoint_url='https://sqs.us-east-2.amazonaws.com',
    )
    sqs_queue_url = sqs_client.get_queue_url(QueueName='mautic_create_contact_queue')['QueueUrl']
        
    for i in event:
        row = i['data']
        
        msg_body = {
            "mautic_contact_id": row[0],
            "ClientID": row[1],
            "EDW_DMS_Customer_ID": row[2],
            "RecipientID": row[3],
            
            "FirstName": row[4],
            "LastName": row[5],
            "EmailAddress": row[6],
            "Address1": row[7],
            "Address2": row[8],
            "City": row[9],
            "State": row[10],
            "ZipCode": row[11],
            
            "LastActivityDate": row[12],
            "ContactType": row[13],
            "LeadStatusType": row[14],
           
            "Sales_Last_VehicleType": row[15],
            "Sales_Last_DealType": row[16],
            "LastVehicleMake": row[17],
            "LastVehicleModel": row[18],
            "LastVehicleYear": row[19],
            "OwnedVehicleBodyStyle": row[20],
            
            "ContractEndDate": row[21],
            "WarrantyEndDate": row[22],
            "Sales_Last_LeaseEndDate": row[23],
            "EstimatedVehicleMileage": row[24],
            "LastTransactionDate": row[25],
            
            "Sales_Last_Date": row[26],
            "Service_Last_Date": row[27],
            "Service_Last_DeclinedDate": row[28],
            "NextServiceAppt": row[29],
            
            "EquityValueRough": row[30],
            "EquityValueAverage": row[31],
            "EquityValueClean": row[32],
            "LeaseEndForecastMileagePenalty": row[33],
            "LeaseEndMileage": row[34],
            "Service_Next_ServiceMileage": row[35],
            "Service_Next_ServiceType": row[36],
            
            "_3BirdsDesiredVehicleType": row[37],
            "_3BirdsDesiredVehicleMake": row[38],
            "_3BirdsDesiredVehicleModel": row[39],
            "_3BirdsDesiredVehicleYear": row[40],
            "_3BirdsDesiredVehicleBodyStyle": row[41],
            
            "CurrentBalance": row[42],
            "CurrentValue": row[43],
            "Service_Last_Department": row[44],
            "SalesPerson": row[45],
            "SalesPersonEmail": row[46],
            "MonthlyPayments": row[47],
            
            "LastOpenDate": row[48],
            "LastClickDate": row[49],
            "Sales_First_Date": row[50],
            "Service_First_Date": row[51],
            "LeadCreateDate": row[52],
            "IsUnsubscribed": row[53],
            
            "LoyaltyAccruedPoints": row[54],
            "LoyaltyAccruedValue": row[55],
            "LoyaltyAccruedDate": row[56],
            
            "GroupID": row[57],
            "_3BirdsDesiredVehicleTrim": row[59],
            "_3BirdsDesiredVehicleInventory": row[60],
            
            "service_last_declined1": row[61],
            "service_last_declined2": row[62],
            "service_last_declined3": row[63],
            "service_last_declined4": row[64],
            "service_last_declined5": row[65],
            
            "avg_miles_perday": row[66],
            "next_service_date": row[67],
            
            "NLO": row[68],
            "NLOReason": row[69],
            
            "CustomerHashKey": row[70]
        }
        print(msg_body)
        ##############
        
        sqs_client.send_message(
            QueueUrl = sqs_queue_url,
            MessageBody = json.dumps(msg_body),
        )
            
    return {
        'statusCode': 200
    }
