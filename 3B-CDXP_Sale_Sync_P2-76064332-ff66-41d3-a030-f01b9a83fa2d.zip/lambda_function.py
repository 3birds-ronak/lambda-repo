import json
import psycopg2
import datetime

def lambda_handler(event, context):
    
    conn = psycopg2.connect(
        database="3B-CDXP",
        user="mauticanalytics",
        password="Mvkor!kens",
        host="analytics-mautics.chxqqwn3nfwz.us-east-2.rds.amazonaws.com",
        port='5432'
    )

    cur1 = conn.cursor()
        
    for i in event:
        row = i['data']
        
        client_id = row[0]
        event_nk = row[1]
        event_date = None if row[2] == None else datetime.datetime.strptime(row[2], "%Y-%m-%d").date()
        event_type = row[3]
        event_properties = {
            "CustomerNumber": row[4],
            "FirstName": row[5],
            "LastName": row[6],
            "Address": row[7],
            "ZIPCode": row[8],
            "EmailAddress": row[9],
            "EmailDomain": row[10],
            
            "VIN": row[11],
            "Make": row[12],
            "Model": row[13],
            "Year": row[14],
            "Type": row[15],
            
            "SalesmanName": row[16],
            "FIManagerName": row[17],
            "DealType": row[18],
            "GrossProfitSale": row[19],
            "CashPrice": row[20],
            "Term": row[21],
            "LeaseFirstPayDate": row[22],
            "ResidualAmount": row[23],
            "ExtendedWarrantyTerm": row[24],
            "ExtendedWarrantyLimitMiles": row[25],
            "FrontGross": row[26],
            "BackGross": row[27],
            
            "TradeInVIN": row[28],
            "TradeInVehicleMake": row[29],
            "TradeInVehicleModel": row[30],
            "TradeInVehicleYear": row[31],
            
            "ContractDate": row[32],
            "Cost": row[33],
            "InvoiceAmount": row[34],
            "LeasePayment": row[35],
            "LeaseNetCapCost": row[36],
            "AccountingDate": row[37],
            "BuyRate": row[38],
            "IsTradeIn": row[39],
            "LeaseEndDate": row[40],
            "LeaseAnnualMiles": row[41],
            "MileageRate": row[42]
        }
        
        ##############
        
        query1 = f"""
            CALL marketing.upsert_event(
                %s, %s, %s, %s, %s
            )
            """
        
        cur1.execute(query1, (client_id, event_nk, event_date, event_type, json.dumps(event_properties)))

        conn.commit()
    
    conn.close()
    
    return {
        'statusCode': 200
    }
