import json
import psycopg2
import datetime

def lambda_handler(event, context):
    
    conn = psycopg2.connect(
        database="3B-CDXP",
        user="mauticanalytics",
        password="Mvkor!kens",
        host="analytics-mautics.chxqqwn3nfwz.us-east-2.rds.amazonaws.com",
        port='5432'
    )

    cur1 = conn.cursor()
        
    for i in event:
        row = i['data']
        
        client_id = row[0]
        event_nk = str(row[1])
        event_date = None if row[2] == None else datetime.datetime.strptime(row[2], "%Y-%m-%d").date()
        event_type = row[3]
        event_properties = {
            "RecipientID": row[4],
            "FirstName": row[5],
            "LastName": row[6],
            "Address1": row[7],
            "Address2": row[8],
            "City": row[9],
            "State": row[10],
            "Country": row[11],
            "ZipCode": row[12],
            "EmailAddress": row[13],
            "EmailDomain": row[14],
            "CellPhone": row[15],
            "WorkPhone": row[16],
            "HomePhone": row[17],
            
            "HostName": row[18],
            "Medium": row[19],
            "Campaign": row[20],
            "SendRequestID": row[21],
            "PagePath": row[22],
            "PreviousPagePath": row[23],
            "IsLandingPage": row[24],
            "InteractionOrder": row[25],
            "ViewMinutes": row[26],
            
            "IsInventory": row[27],
            "IsVehicle": row[28],
            "IsModel": row[29],
            "IsDetail": row[30],
            "IsVIN": row[31],
            "IsCPO": row[32],
            "IsSearchNew": row[33],
            "IsSearchUsed": row[34],
            "IsService": row[35],
            "IsParts": row[36],
            "IsCoupon": row[37],
            "IsSpecials": row[38],
            "IsOffer": row[39],
            "IsFeature": row[40],
            "IsIncentive": row[41],
            "IsLease": row[42],
            "IsFinance": row[43],
            "IsTrade": row[44],
            "IsQuote": row[45],
            "IsMap": row[46],
            "IsDirections": row[47],
            "IsSchedule": row[48],
            "IsContact": row[49]
        }
        
        ##############
        
        query1 = f"""
            CALL marketing.upsert_event(
                %s, %s, %s, %s, %s
            )
            """
        
        cur1.execute(query1, (client_id, event_nk, event_date, event_type, json.dumps(event_properties)))

        conn.commit()
    
    conn.close()
    
    return {
        'statusCode': 200
    }
