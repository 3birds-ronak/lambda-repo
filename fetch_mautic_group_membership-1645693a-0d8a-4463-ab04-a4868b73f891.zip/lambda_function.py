import json
import pyodbc
import boto3
client = boto3.client('lambda', region_name='us-east-2')

def lambda_handler(event, context):
    server = '10.254.210.32' 
    database = 'EDW_target' 
    username = 'helium' 
    password = 'heliumpw'
    
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    cur = conn.cursor()
    cur.execute(f"""
        SELECT m.ClientID, CASE WHEN c.d_mautic_mode <> 'SIMULATOR' THEN 0 ELSE 1 END AS is_simulator
        FROM EDW_target.dbo.Mautic_Instance_Group_Membership m
        LEFT JOIN EDW_target.dbo.Mautic_Company_Mapping c on c.clientid = m.ClientID
        -- WHERE m.ClientID = 173033
        """
    )
    
    for row in cur:
        
        msg_body = {
        	"client_id": row[0],
        	"is_simulator": row[1]
        }
        
        res = client.invoke(
            FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:fetch_CVH_clients_v2',
            InvocationType = 'Event',
            Payload = json.dumps(msg_body)
        )
        
        ############
        
        res = client.invoke(
            FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:3B-CDXP_Appointment_Sync',
            InvocationType = 'Event',
            Payload = json.dumps(msg_body)
        )
        
        res = client.invoke(
            FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:3B-CDXP_GA_Pageview_Sync',
            InvocationType = 'Event',
            Payload = json.dumps(msg_body)
        )
        
        res = client.invoke(
            FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:3B-CDXP_Sale_Sync',
            InvocationType = 'Event',
            Payload = json.dumps(msg_body)
        )
        
        res = client.invoke(
            FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:3B-CDXP_Service_Sync',
            InvocationType = 'Event',
            Payload = json.dumps(msg_body)
        )
    
    ################
    
    res = client.invoke(
        FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:3B-CDXP_Client_Sync',
        InvocationType = 'Event',
        Payload = json.dumps({})
    )
    
    #################
        
    conn.close()
    
    return {
        'statusCode': 200
    }
