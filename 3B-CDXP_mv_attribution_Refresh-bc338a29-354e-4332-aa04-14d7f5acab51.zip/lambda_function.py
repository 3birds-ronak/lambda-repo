import psycopg2
import json
import boto3
client = boto3.client('lambda', region_name='us-east-2')

def lambda_handler(event, context):

    conn = None
    try:
        conn = psycopg2.connect(
            database="3B-CDXP",
            user="mauticanalytics",
            password="Mvkor!kens",
            host="analytics-mautics.chxqqwn3nfwz.us-east-2.rds.amazonaws.com",
            port='5432'
        )
        
        cur = conn.cursor()
        
        query1 = f"""
            REFRESH MATERIALIZED VIEW marketing.mv_attribution
            """
        
        cur.execute(query1)     
            
        conn.commit()
        
        ##################
        
        res = client.invoke(
            FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:3B-CDXP_mv_contact_stats_Refresh',
            InvocationType = 'Event',
            Payload = json.dumps({})
        )
        
    except Exception as e:
        print('Error', e)
        raise e
    finally:
        if conn is not None:
            conn.close()
        print('Finally End')

    return {
        'statusCode': 200,
        'body': 'Success'
    }

if __name__ == "__main__":
    lambda_handler('', '')