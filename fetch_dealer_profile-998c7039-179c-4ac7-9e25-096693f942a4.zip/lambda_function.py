import json
import pyodbc
import boto3
client = boto3.client('lambda', region_name='us-east-2')

def lambda_handler(event, context):
    server = '10.254.210.10' 
    database = 'Lift' 
    username = 'helium' 
    password = 'heliumpw' 
    #clientid = 194665
    
    #############
    
    session = boto3.Session()
    
    sqs_client = session.client(
        service_name='sqs',
        endpoint_url='https://sqs.us-east-2.amazonaws.com',
    )
    sqs_queue_url = sqs_client.get_queue_url(QueueName='mautic_create_company_queue')['QueueUrl']
    
    ################
    
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    cur = conn.cursor()
    cur.execute(f"""
        with company_mappings as (
            SELECT
            	ls.clientid,
            	-- Spreading and aggregation phase
            
            	/* CORE */
            	max(cd.streetaddress1) as address_1,
            	max(cd.city) as city ,
            	max(cd.state) as state ,
            	max(cd.PostalCode) as zip_code,
            	max(cd.FullSiteURL) as full_site_url,
            	max(cd.Latitude) as latitude,
            	max(cd.Longitude) as longitude,
            	max(cd.CountryCode) as country,
            	max(c.BirdClientID) as client_code,
            	max(c.clientname) as company_name,
            	max(cp.clientname) as parent_name,
            	max(c.SenderEmailAddress) as from_email,
            	max(c.NewsletterReplyForwardAddress) as newsletter_reply_email,
            	max(HostName) as site_domain,
            	max(logosquareurl) as square_logo_url,
            	max(logowideurl) as wide_logo_url,
            	max(emailbannerurl) as banner_url,
            	max(description) as description,
            	max(senderemailfromname) as from_name,
            	MAX(CASE WHEN code = '[client]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'client',
            	MAX(CASE WHEN code = '[oem]' THEN case when cast(value as varchar(500)) not in ('#', 'x', 'oem', '[oem]') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'oem',
            	MAX(CASE WHEN code = '[address]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'address',
            	MAX(CASE WHEN code = '[City, State]' THEN case when cast(value as varchar(500)) not in ('#', 'x', 'City, State', '[City, State]') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'city_state',
            	MAX(CASE WHEN code = '[phone]' or code = '[phone_number]' THEN case when cast(value as varchar(500)) not in ('#', 'x', 'Phone Number') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'phone',
            	MAX(CASE WHEN code = '[contact-link]' or code = '[contact-us]' THEN case when cast(value as varchar(500))  like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_contact',
            	MAX(CASE WHEN code = '[schedule-link]'THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_schedule',
            	MAX(CASE WHEN code = '[cpo]' or code = '[cpo-link]'  THEN case when cast(value as varchar(500))  like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_cpo_inventory',
            	MAX(CASE WHEN code = '[used-link]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_used_inventory',
            	MAX(CASE WHEN code = '[new-link]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_new_inventory',
            	MAX(CASE WHEN code = '[home-link]' or code = '[dealer-website]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_website',
            	MAX(CASE WHEN code = '[incentives-link]'THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_incentives',
            	MAX(CASE WHEN code = '[parts-specials]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_parts_specials',
            	MAX(CASE WHEN code = '[tradetool-link]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_tradetool',
            	MAX(CASE WHEN code = '[finance-link]'THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_finance',
            	MAX(CASE WHEN code = '[service-link]' or code = '[servicedept-link]'THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_service',
            	MAX(CASE WHEN code = '[dealer-specials]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_specials',
            	MAX(CASE WHEN code = '[used-specials]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_used_specials',
            	MAX(CASE WHEN code = '[service-specials]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_service_specials',
            	MAX(CASE WHEN code = '[compare-models]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_compare_models',
            	MAX(CASE WHEN code = '[directions-link]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_directions',
            	MAX(CASE WHEN code = '[service-phone]' THEN case when cast(value as varchar(500)) not in ('#', 'x', 'Service Phone Number') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'service_phone',
            	MAX(CASE WHEN code = '[service-director]' THEN case when cast(value as varchar(500)) not in ('#', 'x', 'Service Director''s name') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'service_director',
            	MAX(CASE WHEN code = '[Amenity1]' THEN case when cast(value as varchar(500)) not in ('#', 'x', 'Amentity1') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'amentity_1',
            	MAX(CASE WHEN code = '[Amenity2]' THEN case when cast(value as varchar(500)) not in ('#', 'x', 'Amentity2') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'amentity_2',
            	MAX(CASE WHEN code = '[Amenity3]' THEN case when cast(value as varchar(500)) not in ('#', 'x', 'Amentity3') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'amentity_3',
            	MAX(CASE WHEN code = '[Amenity4]' THEN case when cast(value as varchar(500)) not in ('#', 'x', 'Amentity4') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'amentity_4',
            	MAX(CASE WHEN code = '[dealership-owner]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'dealer_owner',
            	MAX(CASE WHEN code = '[testdrive-link]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_test_drive',
            	MAX(CASE WHEN code = '[RB-yelp]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_review_yelp',
            	MAX(CASE WHEN code = '[RB-google]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_review_google',
            	MAX(CASE WHEN code = '[RB-facebook]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_review_fb',
            	MAX(CASE WHEN code = '[parts-manager]' THEN case when cast(value as varchar(500)) not in ('#', 'x', 'Parts Manager name') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'parts_manager',
            	MAX(CASE WHEN code = '[sales-hours]' THEN case when cast(value as varchar(500)) not like '%0am – 0pm%' and cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'sales_hours',
            	MAX(CASE WHEN code = '[parts-hours]' THEN case when cast(value as varchar(500)) not like '%0am – 0pm%' and cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'parts_hours',
            	MAX(CASE WHEN code = '[service-hours]' THEN case when cast(value as varchar(500)) not like '%0am – 0pm%' and cast(value as varchar(500)) not in ('#', 'x')  then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'service_hours',
            	MAX(CASE WHEN code = '[VDP-Price-Button]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'vdp_price_button',
            	MAX(CASE WHEN code = '[facebook-link]' THEN case when cast(value as varchar(500))like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_social_fb',
            	MAX(CASE WHEN code = '[twitter-link]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'link_social_twitter',
                
                MAX(CASE WHEN code = '[d_mautic_mode]' or code = '[d-mautic-mode]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_mautic_mode',
            	MAX(CASE WHEN code = '[d_email_header]' or code = '[d-email-header]' THEN case when cast(value as varchar(500)) like '%http%' then ltrim(rtrim(cast(value as varchar(500)))) else 'https://' + ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_email_header',
            	MAX(CASE WHEN code = '[d_is_sb]' or code = '[d-is-sb]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_is_service_boost',
            	MAX(CASE WHEN code = '[d_is_sa]' or code = '[d-is-sa]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_is_service_accelerator',
            	MAX(CASE WHEN code = '[d_is_ea]' or code = '[d-is-ea]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_is_equity_accelerator',
            	MAX(CASE WHEN code = '[d_is_ssa]' or code = '[d-is-ssa]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_is_smart_sales_accelerator',
            	MAX(CASE WHEN code = '[d_is_ra]' or code = '[d-is-ra]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_is_retention_accelerator',
            	MAX(CASE WHEN code = '[d_next_tg_date]' or code = '[d-next-tg-date]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_next_tg_date',
            	MAX(CASE WHEN code = '[d_is_la]' or code = '[d-is-la]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_is_la',
            	MAX(CASE WHEN code = '[d_is_rb]' or code = '[d-is-rb]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_is_rb',
            	MAX(CASE WHEN code = '[d_is_ssa_lease]' or code = '[d-is-ssa-lease]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_is_ssa_lease',
            	MAX(CASE WHEN code = '[d_is_ssa_contract]' or code = '[d-is-ssa-contract]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_is_ssa_contract',
                
                MAX(CASE WHEN code = '[d_font_family]' or code = '[d-font-family]' THEN case when cast(value as varchar(1000)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(1000)))) END END) AS 'd_font_family',
            	MAX(CASE WHEN code = '[d_page_bgcolor]' or code = '[d-page-bgcolor]' THEN case when cast(value as varchar(1000)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(1000)))) END END) AS 'd_page_bgcolor',
            	MAX(CASE WHEN code = '[d_header_image]' or code = '[d-header-image]' THEN case when cast(value as varchar(1000)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(1000)))) END END) AS 'd_header_image',
            	MAX(CASE WHEN code = '[d_preheader_bgcolor]' or code = '[d-preheader-bgcolor]' THEN case when cast(value as varchar(1000)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(1000)))) END END) AS 'd_preheader_bgcolor',
            	MAX(CASE WHEN code = '[d_preheader_color]' or code = '[d-preheader-color]' THEN case when cast(value as varchar(1000)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(1000)))) END END) AS 'd_preheader_color',
            	MAX(CASE WHEN code = '[d_body_bgcolor]' or code = '[d-body-bgcolor]' THEN case when cast(value as varchar(1000)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(1000)))) END END) AS 'd_body_bgcolor',
            	MAX(CASE WHEN code = '[d_body_color]' or code = '[d-body-color]' THEN case when cast(value as varchar(1000)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(1000)))) END END) AS 'd_body_color',
            	MAX(CASE WHEN code = '[d_link_color]' or code = '[d-link-color]' THEN case when cast(value as varchar(1000)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(1000)))) END END) AS 'd_link_color',
            	MAX(CASE WHEN code = '[d_brand_color]' or code = '[d-brand-color]' THEN case when cast(value as varchar(1000)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(1000)))) END END) AS 'd_brand_color',
            	MAX(CASE WHEN code = '[d_btn_bgcolor]' or code = '[d-btn-bgcolor]' THEN case when cast(value as varchar(1000)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(1000)))) END END) AS 'd_btn_bgcolor',
            	MAX(CASE WHEN code = '[d_btn_color]' or code = '[d-btn-color]' THEN case when cast(value as varchar(1000)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(1000)))) END END) AS 'd_btn_color',
            	MAX(CASE WHEN code = '[d_btn_radius]' or code = '[d-btn-radius]' THEN case when cast(value as varchar(1000)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(1000)))) END END) AS 'd_btn_radius',
            	
            	/* MILEONE HYUNDAI PILOT */
            	
            	MAX(CASE WHEN code = '[veloster-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_veloster',
            	MAX(CASE WHEN code = '[velostern-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_velostern',
            	MAX(CASE WHEN code = '[sonata-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_sonata',
            	MAX(CASE WHEN code = '[sonatahybrid-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_sonatahybrid',
            	MAX(CASE WHEN code = '[accent-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_accent',
            	MAX(CASE WHEN code = '[elantra-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_elantra',
            	MAX(CASE WHEN code = '[tuscon-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_tuscon',
            	MAX(CASE WHEN code = '[elantragt-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_elantragt',
            	MAX(CASE WHEN code = '[santafe-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_santafe',
            	MAX(CASE WHEN code = '[santafesport-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_santafesport',
            	MAX(CASE WHEN code = '[azera-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_azera',
            	MAX(CASE WHEN code = '[ioniq-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_ioniq',
            	MAX(CASE WHEN code = '[ioniqelectric-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_ioniqelectric',
            	MAX(CASE WHEN code = '[ioniqhybrid-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_ioniqhybrid',
            	MAX(CASE WHEN code = '[kona-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_kona',
            	MAX(CASE WHEN code = '[konaelectric-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_konaelectric',
            	MAX(CASE WHEN code = '[nexo-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_nexo',
            	MAX(CASE WHEN code = '[palisade-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_palisade',
            	MAX(CASE WHEN code = '[venue-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'model_hyundai_venue',
            	
            	/* FORD */
            	MAX(CASE WHEN code = '[bronco-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_bronco',
            	MAX(CASE WHEN code = '[broncosport-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_broncosport',
            	MAX(CASE WHEN code = '[ecosport-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_ecosport',
            	MAX(CASE WHEN code = '[edge-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_edge',
            	MAX(CASE WHEN code = '[escape-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_escape',
            	MAX(CASE WHEN code = '[expedition-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_expedition',
            	MAX(CASE WHEN code = '[explorer-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_explorer',
            	MAX(CASE WHEN code = '[f150-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_f150',
            	MAX(CASE WHEN code = '[f150raptor-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_f150raptor',
            	MAX(CASE WHEN code = '[f150tremor-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_f150tremor',
            	MAX(CASE WHEN code = '[mustang-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_mustang',
            	MAX(CASE WHEN code = '[mache-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_mustangmache',
            	MAX(CASE WHEN code = '[flex-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_flex',
            	MAX(CASE WHEN code = '[focus-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_focus',
            	MAX(CASE WHEN code = '[fusion-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_fusion',
            	MAX(CASE WHEN code = '[fusionhybrid-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_fusionhybrid',
            	MAX(CASE WHEN code = '[fusionenergi-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_fusionplugin',
            	MAX(CASE WHEN code = '[ranger-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_ranger',
            	MAX(CASE WHEN code = '[superduty-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_superduty',
            	MAX(CASE WHEN code = '[transit-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_transit',
            	MAX(CASE WHEN code = '[connect-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ford_transitconnect',
            	/* RAM */
            	MAX(CASE WHEN code = '[1500bighorn-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_1500bighorn',
            	MAX(CASE WHEN code = '[1500longhorn-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_1500longhorn',
            	MAX(CASE WHEN code = '[1500classic-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_1500classic',
            	MAX(CASE WHEN code = '[1500laramie-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_1500laramie',
            	MAX(CASE WHEN code = '[1500rebel-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_1500rebel',
            	MAX(CASE WHEN code = '[1500limited-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_1500limited',
            	MAX(CASE WHEN code = '[1500limitedlonghorn-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_1500limitedlonghorn',
            	MAX(CASE WHEN code = '[1500tradesman-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_1500tradesman',
            	MAX(CASE WHEN code = '[1500trx-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_1500trx',
            	MAX(CASE WHEN code = '[2500-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_2500',
            	MAX(CASE WHEN code = '[laramielonghorn-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_2500laramielonghorn',
            	MAX(CASE WHEN code = '[2500laramie-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_2500laramie',
            	MAX(CASE WHEN code = '[2500tradesman-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_2500tradesman',
            	MAX(CASE WHEN code = '[2500bighorn-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_2500bighorn',
            	MAX(CASE WHEN code = '[2500powerwagon-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_2500powerwagon',
            	MAX(CASE WHEN code = '[2500limited-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_2500limited',
            	MAX(CASE WHEN code = '[3500-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_3500',
            	MAX(CASE WHEN code = '[laramielonghorn-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_3500laramielonghorn',
            	MAX(CASE WHEN code = '[3500laramie-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_3500laramie',
            	MAX(CASE WHEN code = '[3500tradesman-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_3500tradesman',
            	MAX(CASE WHEN code = '[3500bighorn-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_3500bighorn',
            	MAX(CASE WHEN code = '[3500powerwagon-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_3500powerwagon',
            	MAX(CASE WHEN code = '[3500limited-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_3500limited',
            	MAX(CASE WHEN code = '[promastercity-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_promastercity',
            	MAX(CASE WHEN code = '[promastercitywagon-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_promastercitywagon',
            	MAX(CASE WHEN code = '[promaster-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_promaster',
            	MAX(CASE WHEN code = '[chassiscab-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_ram_chassiscab',
            	/* JEEP */
            	MAX(CASE WHEN code = '[wrangler-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_wrangler',
            	MAX(CASE WHEN code = '[wranglermoab-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_wranglermoab',
            	MAX(CASE WHEN code = '[wranglerrubicon-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_wrangler_rubicon',
            	MAX(CASE WHEN code = '[wranglersaharaaltitude-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_wranglersaharaaltitude',
            	MAX(CASE WHEN code = '[wranglersahara-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_wranglersahara',
            	MAX(CASE WHEN code = '[wranglersportaltitude-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_wranglersportaltitude',
            	MAX(CASE WHEN code = '[wranglersport-link]' or code = '[wranglersports-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_wranglersport',
            	MAX(CASE WHEN code = '[wranglerunlimited-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_wranglerunlimited',
            	MAX(CASE WHEN code = '[wranglerunlimitedrubicon-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_wranglerunlimitedrubicon',
            	MAX(CASE WHEN code = '[wranglerunlimitedsahara-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_wranglerunlimitedsahara',
            	MAX(CASE WHEN code = '[wranglerunlimitedsport-link]' or code = '[wranglerunlimitedsports-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_wranglerunlimitedsport',
            	MAX(CASE WHEN code = '[gladiator-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_gladiator',
            	MAX(CASE WHEN code = '[gladiatoroverland-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_gladiatoroverland',
            	MAX(CASE WHEN code = '[gladiatorrubicon-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_gladiatorrubicon',
            	MAX(CASE WHEN code = '[gladiatorsport-link]' or code = '[gladiatorsports-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_gladiatorsport',
            	MAX(CASE WHEN code = '[cherokee-link]' or code = '[cherokeelatitude-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_cherokee',
            	MAX(CASE WHEN code = '[cherokeealtitude-link]' or code = '[cherokeelatitude-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_cherokeealtitude',
            	MAX(CASE WHEN code = '[cherokeelimited-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_cherokeelimited',
            	MAX(CASE WHEN code = '[cherokeehighaltitude-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_cherokeehighaltitude',
            	MAX(CASE WHEN code = '[cherokeelatitudeplus-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_cherokeelatitudeplus',
            	MAX(CASE WHEN code = '[cherokeeoverland-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_cherokeeoverland',
            	MAX(CASE WHEN code = '[cherokeetrailhawk-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_cherokeetrailhawk',
            	MAX(CASE WHEN code = '[cherokeeupland-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_cherokeeupland',
            	MAX(CASE WHEN code = '[compass-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_compass',
            	MAX(CASE WHEN code = '[compasssport-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_compasssport',
            	MAX(CASE WHEN code = '[compasstrailhawk-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_compasstrailhawk',
            	MAX(CASE WHEN code = '[compassupland-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_compassupland',
            	MAX(CASE WHEN code = '[compassaltitude-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_compassaltitude',
            	MAX(CASE WHEN code = '[compasshighaltitude-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_compasshighaltitude',
            	MAX(CASE WHEN code = '[compasslatitude-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_compasslatitude',
            	MAX(CASE WHEN code = '[compasslimited-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_compasslimited',
            	MAX(CASE WHEN code = '[renegade-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_renegade',
            	MAX(CASE WHEN code = '[renegadesport-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_renegadesport',
            	MAX(CASE WHEN code = '[renegadetrailhawk-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_renegadetrailhawk',
            	MAX(CASE WHEN code = '[renegadeupland-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_renegadeupland',
            	MAX(CASE WHEN code = '[renegadealtitude-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_renegadealtitude',
            	MAX(CASE WHEN code = '[renegadehighaltitude-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_renegadehighaltitude',
            	MAX(CASE WHEN code = '[renegadelatitude-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_renegadelatitude',
            	MAX(CASE WHEN code = '[renegadelimited-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_renegadelimited',
            	MAX(CASE WHEN code = '[grandcherokeealtitude-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_grandcherokeealtitude',
            	MAX(CASE WHEN code = '[grandcherokeehighaltitude-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_grandcherokeehighaltitude',
            	MAX(CASE WHEN code = '[grandcherokeelaredo-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_grandcherokeelaredo',
            	MAX(CASE WHEN code = '[grandcherokeelimited-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_grandcherokeelimited',
            	MAX(CASE WHEN code = '[grandcherokeelimitedx-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_grandcherokeelimitedx',
            	MAX(CASE WHEN code = '[grandcherokee-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_grandcherokee',
            	MAX(CASE WHEN code = '[grandcherokeeoverland-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_grandcherokeeoverland',
            	MAX(CASE WHEN code = '[grandcherokeesrt-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_grandcherokeesrt',
            	MAX(CASE WHEN code = '[grandcherokeesummit-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_grandcherokeesummit',
            	MAX(CASE WHEN code = '[grandcherokeetrackhawk-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_grandcherokeetrackhawk',
            	MAX(CASE WHEN code = '[grandcherokeetrailhawk-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_grandcherokeetrailhawk',
            	MAX(CASE WHEN code = '[grandcherokeeupland-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_jeep_grandcherokeeupland',
            	/* DODGE */
            	MAX(CASE WHEN code = '[grandcaravan-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_dodge_grandcaravan',
            	MAX(CASE WHEN code = '[challenger-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_dodge_challenger',
            	MAX(CASE WHEN code = '[srt-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_dodge_challengersrt',
            	MAX(CASE WHEN code = '[charger-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_dodge_charger',
            	MAX(CASE WHEN code = '[durango-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_dodge_durango',
            	MAX(CASE WHEN code = '[journey-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_dodge_journey',
            	/* Chrysler */
            	MAX(CASE WHEN code = '[300-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_cry_300',
            	MAX(CASE WHEN code = '[pacficahybrid-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_cry_pacficahybrid',
            	MAX(CASE WHEN code = '[pacifica-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_cry_pacifica',
            	MAX(CASE WHEN code = '[voyager-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_cry_voyager',
            	/* CHEV */
            	MAX(CASE WHEN code = '[blazer-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_blazer',
            	MAX(CASE WHEN code = '[camaro-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_camaro',
            	MAX(CASE WHEN code = '[bolt-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_bolt',
            	MAX(CASE WHEN code = '[boltev-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_boltev',
            	MAX(CASE WHEN code = '[colorado-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_colorado',
            	MAX(CASE WHEN code = '[corvette-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_corvette',
            	MAX(CASE WHEN code = '[corvettestingray-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_corvettestingray',
            	MAX(CASE WHEN code = '[corvettegrandsport-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_corvettegrandsport',
            	MAX(CASE WHEN code = '[corvettez06-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_corvettez06',
            	MAX(CASE WHEN code = '[corvettezr1-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_corvettezr1',
            	MAX(CASE WHEN code = '[equinox-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_equinox',
            	MAX(CASE WHEN code = '[malibu-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_malibu',
            	MAX(CASE WHEN code = '[spark-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_spark',
            	MAX(CASE WHEN code = '[tahoe-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_tahoe',
            	MAX(CASE WHEN code = '[suburban-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_suburban',
            	MAX(CASE WHEN code = '[trailblazer-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_trailblazer',
            	MAX(CASE WHEN code = '[traverse-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_traverse',
            	MAX(CASE WHEN code = '[trax-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_trax',
            	MAX(CASE WHEN code = '[silverado1500-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_silverado1500',
            	MAX(CASE WHEN code = '[silverado2500HD-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_silverado2500hd',
            	MAX(CASE WHEN code = '[silveradohd-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_silveradohd',
            	MAX(CASE WHEN code = '[silverado-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_silverado',
            	MAX(CASE WHEN code = '[sonic-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_chev_sonic',
            	/* GMC */
            	MAX(CASE WHEN code = '[canyonallterrain-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_canyonallterrain',
            	MAX(CASE WHEN code = '[canyondenali-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_canyondenali',
            	MAX(CASE WHEN code = '[canyon-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_canyon',
            	MAX(CASE WHEN code = '[sierra1500at4-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_sierra1500at4',
            	MAX(CASE WHEN code = '[sierra1500denali-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_sierra1500denali',
            	MAX(CASE WHEN code = '[sierra1500-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_sierra1500',
            	MAX(CASE WHEN code = '[sierra2500hdat4-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_sierra2500hdat4',
            	MAX(CASE WHEN code = '[sierra2500hddenali-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_sierra2500hddenali',
            	MAX(CASE WHEN code = '[sierra2500-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_sierra2500',
            	MAX(CASE WHEN code = '[sierra3500hdat4-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_sierra3500hdat4',
            	MAX(CASE WHEN code = '[sierra3500hddenali-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_sierra3500hddenali',
            	MAX(CASE WHEN code = '[sierra3500-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_sierra3500',
            	MAX(CASE WHEN code = '[sierrahd-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_sierrahd',
            	MAX(CASE WHEN code = '[acadiaat4-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_acadiaat4',
            	MAX(CASE WHEN code = '[acadiadenali-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_cacadiadenali',
            	MAX(CASE WHEN code = '[acadia-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_acadia',
            	MAX(CASE WHEN code = '[terraindenali-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_terraindenali',
            	MAX(CASE WHEN code = '[terrain-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_terrain',
            	MAX(CASE WHEN code = '[yukondenali-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_yukondenali',
            	MAX(CASE WHEN code = '[yukonxldenali-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_yukonxldenali',
            	MAX(CASE WHEN code = '[yukonxl-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_yukonxl',
            	MAX(CASE WHEN code = '[yukon-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_yukon',
            	MAX(CASE WHEN code = '[savanacargo-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_savanacargo',
            	MAX(CASE WHEN code = '[savanacutaway-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_savanacutaway',
            	MAX(CASE WHEN code = '[savanapassenger-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_gmc_savanapassenger',
            	/* BUICK */
            	MAX(CASE WHEN code = '[enclaveavenir-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_buick_enclaveavenir',
            	MAX(CASE WHEN code = '[enclave-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_buick_enclave',
            	MAX(CASE WHEN code = '[encoregx-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_buick_encoregx',
            	MAX(CASE WHEN code = '[encoregxst-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_buick_encoregxst',
            	MAX(CASE WHEN code = '[encore-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_buick_encore',
            	MAX(CASE WHEN code = '[envision-link]' THEN case when cast(value as varchar(500)) not in ('#', 'x') then ltrim(rtrim(cast(value as varchar(500)))) END END) AS 'd_buick_envision'
            	
            from
             
            	[Lift].[dbo].[Lift_Site_Shortcode_Overrides]  oc
            	inner join [Lift].[dbo].[lift_sites] ls on
            		oc.SiteId = ls.siteid 
            	inner join [ClientDB].[dbo].[Clients] c on
            		ls.ClientId = c.ClientId
            	inner join [ClientDB].[dbo].[ClientDetails] cd on
            		ls.ClientId = cd.ClientId
            	left outer join [ClientDB].[dbo].[Clients] cp on
            		c.ParentGroupID = cp.ClientId
            where
            	ls.clientid in (select
            			clientid
            		from
            			clientdb.[dbo].[ClientGroupMemberships]
            		where
            			groupid = 541)
            GROUP BY 
            	ls.clientid
        )
            
        SELECT m.mautic_company_id, t.*, m.mautic_company_id_simulator FROM (
        	SELECT 
        		company_mappings.[clientid], [address_1], [city], [state], [zip_code], [full_site_url], [latitude], [longitude], [country], [client_code], [company_name], [parent_name], [from_email]
        		,[newsletter_reply_email], [site_domain], [square_logo_url], [wide_logo_url], [banner_url], [description], [from_name], [client], [oem], [address], [city_state], [phone]
        		,[link_contact], [link_schedule], [link_cpo_inventory], [link_used_inventory], [link_new_inventory], [link_website], [link_incentives], [link_parts_specials]
        		,[link_tradetool], [link_finance], [link_service], [link_specials], [link_used_specials], [link_service_specials], [link_compare_models], [link_directions]
        		,[service_phone], [service_director], [dealer_owner], [link_test_drive], [link_review_yelp], [link_review_google], [link_review_fb], [parts_manager]
        		,[sales_hours], [parts_hours], [service_hours], [vdp_price_button], [link_social_fb], [link_social_twitter]
        		,[model_hyundai_veloster], [model_hyundai_velostern], [model_hyundai_sonata], [model_hyundai_sonatahybrid], [model_hyundai_accent], [model_hyundai_elantra]
        		,[model_hyundai_tuscon], [model_hyundai_elantragt], [model_hyundai_santafe], [model_hyundai_santafesport], [model_hyundai_azera], [model_hyundai_ioniq]
        		,[model_hyundai_ioniqelectric], [model_hyundai_ioniqhybrid], [model_hyundai_kona], [model_hyundai_konaelectric], [model_hyundai_nexo], [model_hyundai_palisade]
        		,[model_hyundai_venue],
        		case 
        			when amentity_1  is not null and amentity_2 is not null and amentity_3 is not null and amentity_4 is not null then '[''' + amentity_1 + ''',''' + amentity_2 + ''',''' + amentity_3 + ''',''' + amentity_4 + ''']'
        			when amentity_1  is not null and amentity_2 is not null and amentity_3 is not null then '[''' + amentity_1 + ''',''' + amentity_2 + ''',''' + amentity_3 + ''']'
        			when amentity_1  is not null and amentity_2 is not null then '[''' + amentity_1 + ''',''' + amentity_2 + ''']'
        			when amentity_1  is not null then '[''' + amentity_1 + ''']'
        			else NULL
        		end as amenities
        		,m.GroupID
        		
        		,[d_ford_bronco], [d_ford_broncosport], [d_ford_ecosport], [d_ford_edge], [d_ford_escape], [d_ford_expedition], [d_ford_explorer], [d_ford_f150], [d_ford_f150raptor]
        		,[d_ford_f150tremor], [d_ford_mustang], [d_ford_mustangmache], [d_ford_flex], [d_ford_focus], [d_ford_fusion], [d_ford_fusionhybrid], [d_ford_fusionplugin], [d_ford_ranger]
        		,[d_ford_superduty], [d_ford_transit], [d_ford_transitconnect]
        		
        		,[d_ram_1500bighorn], [d_ram_1500longhorn], [d_ram_1500classic], [d_ram_1500laramie], [d_ram_1500rebel], [d_ram_1500limited], [d_ram_1500limitedlonghorn], [d_ram_1500tradesman], [d_ram_1500trx]
        		,[d_ram_2500], [d_ram_2500laramielonghorn], [d_ram_2500laramie], [d_ram_2500tradesman], [d_ram_2500bighorn], [d_ram_2500powerwagon], [d_ram_2500limited], [d_ram_3500], [d_ram_3500laramielonghorn]
        		,[d_ram_3500laramie], [d_ram_3500tradesman], [d_ram_3500bighorn], [d_ram_3500powerwagon], [d_ram_3500limited], [d_ram_promastercity], [d_ram_promastercitywagon], [d_ram_promaster], [d_ram_chassiscab]
        
        		,[d_jeep_wrangler], [d_jeep_wranglermoab], [d_jeep_wrangler_rubicon], [d_jeep_wranglersaharaaltitude], [d_jeep_wranglersahara], [d_jeep_wranglersportaltitude], [d_jeep_wranglersport], [d_jeep_wranglerunlimited], [d_jeep_wranglerunlimitedrubicon]
        		,[d_jeep_wranglerunlimitedsahara], [d_jeep_wranglerunlimitedsport], [d_jeep_gladiator], [d_jeep_gladiatoroverland], [d_jeep_gladiatorrubicon], [d_jeep_gladiatorsport], [d_jeep_cherokee], [d_jeep_cherokeealtitude], [d_jeep_cherokeelimited]
        		,[d_jeep_cherokeehighaltitude], [d_jeep_cherokeelatitudeplus], [d_jeep_cherokeeoverland], [d_jeep_cherokeetrailhawk], [d_jeep_cherokeeupland], [d_jeep_compass], [d_jeep_compasssport], [d_jeep_compasstrailhawk], [d_jeep_compassupland]
        		,[d_jeep_compassaltitude], [d_jeep_compasshighaltitude], [d_jeep_compasslatitude], [d_jeep_compasslimited], [d_jeep_renegade], [d_jeep_renegadesport], [d_jeep_renegadetrailhawk], [d_jeep_renegadeupland], [d_jeep_renegadealtitude]
        		,[d_jeep_renegadehighaltitude], [d_jeep_renegadelatitude], [d_jeep_renegadelimited], [d_jeep_grandcherokeealtitude], [d_jeep_grandcherokeehighaltitude], [d_jeep_grandcherokeelaredo], [d_jeep_grandcherokeelimited], [d_jeep_grandcherokeelimitedx]
        		,[d_jeep_grandcherokee], [d_jeep_grandcherokeeoverland], [d_jeep_grandcherokeesrt], [d_jeep_grandcherokeesummit], [d_jeep_grandcherokeetrackhawk], [d_jeep_grandcherokeetrailhawk], [d_jeep_grandcherokeeupland]
        
        		,[d_dodge_grandcaravan], [d_dodge_challenger], [d_dodge_challengersrt], [d_dodge_charger], [d_dodge_durango], [d_dodge_journey]
        
        		,[d_cry_300], [d_cry_pacficahybrid], [d_cry_pacifica], [d_cry_voyager]
        
        		,[d_chev_blazer], [d_chev_camaro], [d_chev_bolt], [d_chev_boltev], [d_chev_colorado], [d_chev_corvette], [d_chev_corvettestingray], [d_chev_corvettegrandsport]
        		,[d_chev_corvettez06], [d_chev_corvettezr1], [d_chev_equinox], [d_chev_malibu], [d_chev_spark], [d_chev_tahoe], [d_chev_suburban], [d_chev_trailblazer]
        		,[d_chev_traverse], [d_chev_trax], [d_chev_silverado1500], [d_chev_silverado2500hd], [d_chev_silveradohd], [d_chev_silverado], [d_chev_sonic]
        
        		,[d_gmc_canyonallterrain], [d_gmc_canyondenali], [d_gmc_canyon], [d_gmc_sierra1500at4], [d_gmc_sierra1500denali], [d_gmc_sierra1500], [d_gmc_sierra2500hdat4], [d_gmc_sierra2500hddenali]
        		,[d_gmc_sierra2500], [d_gmc_sierra3500hdat4], [d_gmc_sierra3500hddenali], [d_gmc_sierra3500], [d_gmc_sierrahd], [d_gmc_acadiaat4], [d_gmc_cacadiadenali], [d_gmc_acadia]
        		,[d_gmc_terraindenali], [d_gmc_terrain], [d_gmc_yukondenali], [d_gmc_yukonxldenali], [d_gmc_yukonxl], [d_gmc_yukon], [d_gmc_savanacargo], [d_gmc_savanacutaway], [d_gmc_savanapassenger]
        
        		,[d_buick_enclaveavenir], [d_buick_enclave], [d_buick_encoregx], [d_buick_encoregxst], [d_buick_encore], [d_buick_envision]
        		
        		,coalesce([d_mautic_mode], 'SIMULATOR') as d_mautic_mode, [d_email_header], coalesce([d_is_service_boost], 'TRUE') as d_is_service_boost
        		,coalesce([d_is_service_accelerator], 'TRUE') as d_is_service_accelerator, coalesce([d_is_equity_accelerator], 'TRUE') as d_is_equity_accelerator
        		,coalesce([d_is_smart_sales_accelerator], 'TRUE') as d_is_smart_sales_accelerator,coalesce([d_is_retention_accelerator], 'TRUE') as d_is_retention_accelerator
        		,[d_next_tg_date], coalesce([d_is_la], 'TRUE') as d_is_la, coalesce([d_is_rb], 'FALSE') as d_is_rb, coalesce([d_is_ssa_lease], 'FALSE') as d_is_ssa_lease
		        ,coalesce([d_is_ssa_contract], 'FALSE') as d_is_ssa_contract
        		
        		,[d_font_family], [d_page_bgcolor], [d_header_image], [d_preheader_bgcolor], [d_preheader_color], [d_body_bgcolor]
        		,[d_body_color], [d_link_color], [d_brand_color], [d_btn_bgcolor], [d_btn_color], [d_btn_radius]
        	FROM company_mappings
        	JOIN [3bhsetl01].[EDW_target].[dbo].[Mautic_Instance_Group_Membership] m ON m.ClientID = company_mappings.clientid
        	EXCEPT
        	SELECT 
        		[clientid], [address_1], [city], [state], [zip_code], [full_site_url], [latitude], [longitude], [country], [client_code], [company_name], [parent_name], [from_email]
        		,[newsletter_reply_email], [site_domain], [square_logo_url], [wide_logo_url], [banner_url], [description], [from_name], [client], [oem], [address], [city_state], [phone]
        		,[link_contact], [link_schedule], [link_cpo_inventory], [link_used_inventory], [link_new_inventory], [link_website], [link_incentives], [link_parts_specials]
        		,[link_tradetool], [link_finance], [link_service], [link_specials], [link_used_specials], [link_service_specials], [link_compare_models], [link_directions]
        		,[service_phone], [service_director], [dealer_owner], [link_test_drive], [link_review_yelp], [link_review_google], [link_review_fb], [parts_manager]
        		,[sales_hours], [parts_hours], [service_hours], [vdp_price_button], [link_social_fb], [link_social_twitter]
        		,[model_hyundai_veloster], [model_hyundai_velostern], [model_hyundai_sonata], [model_hyundai_sonatahybrid], [model_hyundai_accent], [model_hyundai_elantra]
        		,[model_hyundai_tuscon], [model_hyundai_elantragt], [model_hyundai_santafe], [model_hyundai_santafesport], [model_hyundai_azera], [model_hyundai_ioniq]
        		,[model_hyundai_ioniqelectric], [model_hyundai_ioniqhybrid], [model_hyundai_kona], [model_hyundai_konaelectric], [model_hyundai_nexo], [model_hyundai_palisade]
        		,[model_hyundai_venue]
        		,[amenities]
        		,GroupID
        		
        		,[d_ford_bronco], [d_ford_broncosport], [d_ford_ecosport], [d_ford_edge], [d_ford_escape], [d_ford_expedition], [d_ford_explorer], [d_ford_f150], [d_ford_f150raptor]
        		,[d_ford_f150tremor], [d_ford_mustang], [d_ford_mustangmache], [d_ford_flex], [d_ford_focus], [d_ford_fusion], [d_ford_fusionhybrid], [d_ford_fusionplugin], [d_ford_ranger]
        		,[d_ford_superduty], [d_ford_transit], [d_ford_transitconnect]
        		
        		,[d_ram_1500bighorn], [d_ram_1500longhorn], [d_ram_1500classic], [d_ram_1500laramie], [d_ram_1500rebel], [d_ram_1500limited], [d_ram_1500limitedlonghorn], [d_ram_1500tradesman], [d_ram_1500trx]
        		,[d_ram_2500], [d_ram_2500laramielonghorn], [d_ram_2500laramie], [d_ram_2500tradesman], [d_ram_2500bighorn], [d_ram_2500powerwagon], [d_ram_2500limited], [d_ram_3500], [d_ram_3500laramielonghorn]
        		,[d_ram_3500laramie], [d_ram_3500tradesman], [d_ram_3500bighorn], [d_ram_3500powerwagon], [d_ram_3500limited], [d_ram_promastercity], [d_ram_promastercitywagon], [d_ram_promaster], [d_ram_chassiscab]
        
        		,[d_jeep_wrangler], [d_jeep_wranglermoab], [d_jeep_wrangler_rubicon], [d_jeep_wranglersaharaaltitude], [d_jeep_wranglersahara], [d_jeep_wranglersportaltitude], [d_jeep_wranglersport], [d_jeep_wranglerunlimited], [d_jeep_wranglerunlimitedrubicon]
        		,[d_jeep_wranglerunlimitedsahara], [d_jeep_wranglerunlimitedsport], [d_jeep_gladiator], [d_jeep_gladiatoroverland], [d_jeep_gladiatorrubicon], [d_jeep_gladiatorsport], [d_jeep_cherokee], [d_jeep_cherokeealtitude], [d_jeep_cherokeelimited]
        		,[d_jeep_cherokeehighaltitude], [d_jeep_cherokeelatitudeplus], [d_jeep_cherokeeoverland], [d_jeep_cherokeetrailhawk], [d_jeep_cherokeeupland], [d_jeep_compass], [d_jeep_compasssport], [d_jeep_compasstrailhawk], [d_jeep_compassupland]
        		,[d_jeep_compassaltitude], [d_jeep_compasshighaltitude], [d_jeep_compasslatitude], [d_jeep_compasslimited], [d_jeep_renegade], [d_jeep_renegadesport], [d_jeep_renegadetrailhawk], [d_jeep_renegadeupland], [d_jeep_renegadealtitude]
        		,[d_jeep_renegadehighaltitude], [d_jeep_renegadelatitude], [d_jeep_renegadelimited], [d_jeep_grandcherokeealtitude], [d_jeep_grandcherokeehighaltitude], [d_jeep_grandcherokeelaredo], [d_jeep_grandcherokeelimited], [d_jeep_grandcherokeelimitedx]
        		,[d_jeep_grandcherokee], [d_jeep_grandcherokeeoverland], [d_jeep_grandcherokeesrt], [d_jeep_grandcherokeesummit], [d_jeep_grandcherokeetrackhawk], [d_jeep_grandcherokeetrailhawk], [d_jeep_grandcherokeeupland]
        
        		,[d_dodge_grandcaravan], [d_dodge_challenger], [d_dodge_challengersrt], [d_dodge_charger], [d_dodge_durango], [d_dodge_journey]
        
        		,[d_cry_300], [d_cry_pacficahybrid], [d_cry_pacifica], [d_cry_voyager]
        
        		,[d_chev_blazer], [d_chev_camaro], [d_chev_bolt], [d_chev_boltev], [d_chev_colorado], [d_chev_corvette], [d_chev_corvettestingray], [d_chev_corvettegrandsport]
        		,[d_chev_corvettez06], [d_chev_corvettezr1], [d_chev_equinox], [d_chev_malibu], [d_chev_spark], [d_chev_tahoe], [d_chev_suburban], [d_chev_trailblazer]
        		,[d_chev_traverse], [d_chev_trax], [d_chev_silverado1500], [d_chev_silverado2500hd], [d_chev_silveradohd], [d_chev_silverado], [d_chev_sonic]
        
        		,[d_gmc_canyonallterrain], [d_gmc_canyondenali], [d_gmc_canyon], [d_gmc_sierra1500at4], [d_gmc_sierra1500denali], [d_gmc_sierra1500], [d_gmc_sierra2500hdat4], [d_gmc_sierra2500hddenali]
        		,[d_gmc_sierra2500], [d_gmc_sierra3500hdat4], [d_gmc_sierra3500hddenali], [d_gmc_sierra3500], [d_gmc_sierrahd], [d_gmc_acadiaat4], [d_gmc_cacadiadenali], [d_gmc_acadia]
        		,[d_gmc_terraindenali], [d_gmc_terrain], [d_gmc_yukondenali], [d_gmc_yukonxldenali], [d_gmc_yukonxl], [d_gmc_yukon], [d_gmc_savanacargo], [d_gmc_savanacutaway], [d_gmc_savanapassenger]
        
        		,[d_buick_enclaveavenir], [d_buick_enclave], [d_buick_encoregx], [d_buick_encoregxst], [d_buick_encore], [d_buick_envision]
        		
        		,[d_mautic_mode], [d_email_header], [d_is_service_boost]
        		,[d_is_service_accelerator], [d_is_equity_accelerator]
        		,[d_is_smart_sales_accelerator], [d_is_retention_accelerator]
        		,[d_next_tg_date], [d_is_la], [d_is_rb], [d_is_ssa_lease]
		        ,[d_is_ssa_contract]
        		
        		,[d_font_family], [d_page_bgcolor], [d_header_image], [d_preheader_bgcolor], [d_preheader_color], [d_body_bgcolor]
        		,[d_body_color], [d_link_color], [d_brand_color], [d_btn_bgcolor], [d_btn_color], [d_btn_radius]
		
        	FROM [3bhsetl01].[EDW_target].[dbo].[Mautic_Company_Mapping]
        ) t
        LEFT JOIN [3bhsetl01].[EDW_target].[dbo].[Mautic_Company_Mapping] m ON m.clientid = t.clientid
        """
    )
    
    for row in cur:
        
        msg_body = {
            "mautic_company_id": row[0],
            "clientid": row[1],
            "address_1": row[2],
            "city": row[3],
            "state": row[4],
            "zip_code": row[5],
            "full_site_url": row[6],
            "latitude": row[7],
            "longitude": row[8],
            "country": row[9],
            "client_code": row[10],
            "company_name": row[11],
            "parent_name": row[12],
            "from_email": row[13],
            "newsletter_reply_email": row[14],
            "site_domain": row[15],
            "square_logo_url": row[16],
            "wide_logo_url": row[17],
            "banner_url": row[18],
            "description": row[19],
            "from_name": row[20],
            "client": row[21],
            "oem": row[22],
            "address": row[23],
            "city_state": row[24],
            "phone": row[25],
            "link_contact": row[26],
            "link_schedule": row[27],
            "link_cpo_inventory": row[28],
            "link_used_inventory": row[29],
            "link_new_inventory": row[30],
            "link_website": row[31],
            "link_incentives": row[32],
            "link_parts_specials": row[33],
            "link_tradetool": row[34],
            "link_finance": row[35],
            "link_service": row[36],
            "link_specials": row[37],
            "link_used_specials": row[38],
            "link_service_specials": row[39],
            "link_compare_models": row[40],
            "link_directions": row[41],
            "service_phone": row[42],
            "service_director": row[43],
            "dealer_owner": row[44],
            "link_test_drive": row[45],
            "link_review_yelp": row[46],
            "link_review_google": row[47],
            "link_review_fb": row[48],
            "parts_manager": row[49],
            "sales_hours": row[50],
            "parts_hours": row[51],
            "service_hours": row[52],
            "vdp_price_button": row[53],
            "link_social_fb": row[54],
            "link_social_twitter": row[55],
            
            "model_hyundai_veloster": row[56],
            "model_hyundai_velostern": row[57],
            "model_hyundai_sonata": row[58],
            "model_hyundai_sonatahybrid": row[59],
            "model_hyundai_accent": row[60],
            "model_hyundai_elantra": row[61],
            "model_hyundai_tuscon": row[62],
            "model_hyundai_elantragt": row[63],
            "model_hyundai_santafe": row[64],
            "model_hyundai_santafesport": row[65],
            "model_hyundai_azera": row[66],
            "model_hyundai_ioniq": row[67],
            "model_hyundai_ioniqelectric": row[68],
            "model_hyundai_ioniqhybrid": row[69],
            "model_hyundai_kona": row[70],
            "model_hyundai_konaelectric": row[71],
            "model_hyundai_nexo": row[72],
            "model_hyundai_palisade": row[73],
            "model_hyundai_venue": row[74],
            
            "amenities": row[75],
            "GroupID": row[76],
            
            "d_ford_bronco": row[77],
            "d_ford_broncosport": row[78],
            "d_ford_ecosport": row[79],
            "d_ford_edge": row[80],
            "d_ford_escape": row[81],
            "d_ford_expedition": row[82],
            "d_ford_explorer": row[83],
            "d_ford_f150": row[84],
            "d_ford_f150raptor": row[85],
            "d_ford_f150tremor": row[86],
            "d_ford_mustang": row[87],
            "d_ford_mustangmache": row[88],
            "d_ford_flex": row[89],
            "d_ford_focus": row[90],
            "d_ford_fusion": row[91],
            "d_ford_fusionhybrid": row[92],
            "d_ford_fusionplugin": row[93],
            "d_ford_ranger": row[94],
            "d_ford_superduty": row[95],
            "d_ford_transit": row[96],
            "d_ford_transitconnect": row[97],
            
            "d_ram_1500bighorn": row[98],
            "d_ram_1500longhorn": row[99],
            "d_ram_1500classic": row[100],
            "d_ram_1500laramie": row[101],
            "d_ram_1500rebel": row[102],
            "d_ram_1500limited": row[103],
            "d_ram_1500limitedlonghorn": row[104],
            "d_ram_1500tradesman": row[105],
            "d_ram_1500trx": row[106],
            "d_ram_2500": row[107],
            "d_ram_2500laramielonghorn": row[108],
            "d_ram_2500laramie": row[109],
            "d_ram_2500tradesman": row[110],
            "d_ram_2500bighorn": row[111],
            "d_ram_2500powerwagon": row[112],
            "d_ram_2500limited": row[113],
            "d_ram_3500": row[114],
            "d_ram_3500laramielonghorn": row[115],
            "d_ram_3500laramie": row[116],
            "d_ram_3500tradesman": row[117],
            "d_ram_3500bighorn": row[118],
            "d_ram_3500powerwagon": row[119],
            "d_ram_3500limited": row[120],
            "d_ram_promastercity": row[121],
            "d_ram_promastercitywagon": row[122],
            "d_ram_promaster": row[123],
            "d_ram_chassiscab": row[124],
            
            "d_jeep_wrangler": row[125],
            "d_jeep_wranglermoab": row[126],
            "d_jeep_wrangler_rubicon": row[127],
            "d_jeep_wranglersaharaaltitude": row[128],
            "d_jeep_wranglersahara": row[129],
            "d_jeep_wranglersportaltitude": row[130],
            "d_jeep_wranglersport": row[131],
            "d_jeep_wranglerunlimited": row[132],
            "d_jeep_wranglerunlimitedrubicon": row[133],
            "d_jeep_wranglerunlimitedsahara": row[134],
            "d_jeep_wranglerunlimitedsport": row[135],
            "d_jeep_gladiator": row[136],
            "d_jeep_gladiatoroverland": row[137],
            "d_jeep_gladiatorrubicon": row[138],
            "d_jeep_gladiatorsport": row[139],
            "d_jeep_cherokee": row[140],
            "d_jeep_cherokeealtitude": row[141],
            "d_jeep_cherokeelimited": row[142],
            "d_jeep_cherokeehighaltitude": row[143],
            "d_jeep_cherokeelatitudeplus": row[144],
            "d_jeep_cherokeeoverland": row[145],
            "d_jeep_cherokeetrailhawk": row[146],
            "d_jeep_cherokeeupland": row[147],
            "d_jeep_compass": row[148],
            "d_jeep_compasssport": row[149],
            "d_jeep_compasstrailhawk": row[150],
            "d_jeep_compassupland": row[151],
            "d_jeep_compassaltitude": row[152],
            "d_jeep_compasshighaltitude": row[153],
            "d_jeep_compasslatitude": row[154],
            "d_jeep_compasslimited": row[155],
            "d_jeep_renegade": row[156],
            "d_jeep_renegadesport": row[157],
            "d_jeep_renegadetrailhawk": row[158],
            "d_jeep_renegadeupland": row[159],
            "d_jeep_renegadealtitude": row[160],
            "d_jeep_renegadehighaltitude": row[161],
            "d_jeep_renegadelatitude": row[162],
            "d_jeep_renegadelimited": row[163],
            "d_jeep_grandcherokeealtitude": row[164],
            "d_jeep_grandcherokeehighaltitude": row[165],
            "d_jeep_grandcherokeelaredo": row[166],
            "d_jeep_grandcherokeelimited": row[167],
            "d_jeep_grandcherokeelimitedx": row[168],
            "d_jeep_grandcherokee": row[169],
            "d_jeep_grandcherokeeoverland": row[170],
            "d_jeep_grandcherokeesrt": row[171],
            "d_jeep_grandcherokeesummit": row[172],
            "d_jeep_grandcherokeetrackhawk": row[173],
            "d_jeep_grandcherokeetrailhawk": row[174],
            "d_jeep_grandcherokeeupland": row[175],
            
            "d_dodge_grandcaravan": row[176],
            "d_dodge_challenger": row[177],
            "d_dodge_challengersrt": row[178],
            "d_dodge_charger": row[179],
            "d_dodge_durango": row[180],
            "d_dodge_journey": row[181],
            
            "d_cry_300": row[182],
            "d_cry_pacficahybrid": row[183],
            "d_cry_pacifica": row[184],
            "d_cry_voyager": row[185],
            
            "d_chev_blazer": row[186],
            "d_chev_camaro": row[187],
            "d_chev_bolt": row[188],
            "d_chev_boltev": row[189],
            "d_chev_colorado": row[190],
            "d_chev_corvette": row[191],
            "d_chev_corvettestingray": row[192],
            "d_chev_corvettegrandsport": row[193],
            "d_chev_corvettez06": row[194],
            "d_chev_corvettezr1": row[195],
            "d_chev_equinox": row[196],
            "d_chev_malibu": row[197],
            "d_chev_spark": row[198],
            "d_chev_tahoe": row[199],
            "d_chev_suburban": row[200],
            "d_chev_trailblazer": row[201],
            "d_chev_traverse": row[202],
            "d_chev_trax": row[203],
            "d_chev_silverado1500": row[204],
            "d_chev_silverado2500hd": row[205],
            "d_chev_silveradohd": row[206],
            "d_chev_silverado": row[207],
            "d_chev_sonic": row[208],
            
            "d_gmc_canyonallterrain": row[209],
            "d_gmc_canyondenali": row[210],
            "d_gmc_canyon": row[211],
            "d_gmc_sierra1500at4": row[212],
            "d_gmc_sierra1500denali": row[213],
            "d_gmc_sierra1500": row[214],
            "d_gmc_sierra2500hdat4": row[215],
            "d_gmc_sierra2500hddenali": row[216],
            "d_gmc_sierra2500": row[217],
            "d_gmc_sierra3500hdat4": row[218],
            "d_gmc_sierra3500hddenali": row[219],
            "d_gmc_sierra3500": row[220],
            "d_gmc_sierrahd": row[221],
            "d_gmc_acadiaat4": row[222],
            "d_gmc_cacadiadenali": row[223],
            "d_gmc_acadia": row[224],
            "d_gmc_terraindenali": row[225],
            "d_gmc_terrain": row[226],
            "d_gmc_yukondenali": row[227],
            "d_gmc_yukonxldenali": row[228],
            "d_gmc_yukonxl": row[229],
            "d_gmc_yukon": row[230],
            "d_gmc_savanacargo": row[231],
            "d_gmc_savanacutaway": row[232],
            "d_gmc_savanapassenger": row[233],
            
            "d_buick_enclaveavenir": row[234],
            "d_buick_enclave": row[235],
            "d_buick_encoregx": row[236],
            "d_buick_encoregxst": row[237],
            "d_buick_encore": row[238],
            "d_buick_envision": row[239],
           
            "d_mautic_mode": row[240],
            "d_email_header": row[241],
            "d_is_service_boost": row[242],
            "d_is_service_accelerator": row[243],
            "d_is_equity_accelerator": row[244],
            "d_is_smart_sales_accelerator": row[245],
            "d_is_retention_accelerator": row[246],
            "d_next_tg_date": row[247],
            "d_is_la": row[248],
            "d_is_rb": row[249],
            "d_is_ssa_lease": row[250],
            "d_is_ssa_contract": row[251],
            
            "d_font_family": row[252],
            "d_page_bgcolor": row[253],
            "d_header_image": row[254],
            "d_preheader_bgcolor": row[255],
            "d_preheader_color": row[256],
            "d_body_bgcolor": row[257],
            "d_body_color": row[258],
            "d_link_color": row[259],
            "d_brand_color": row[260],
            "d_btn_bgcolor": row[261],
            "d_btn_color": row[262],
            "d_btn_radius": row[263],
            
            "mautic_company_id_simulator": row[264] 
        }
        
        print(msg_body)
        
        sqs_client.send_message(
            QueueUrl = sqs_queue_url,
            MessageBody = json.dumps(msg_body),
        )
        
    conn.close()
    
    return {
        'statusCode': 200
    }
        
    
    

