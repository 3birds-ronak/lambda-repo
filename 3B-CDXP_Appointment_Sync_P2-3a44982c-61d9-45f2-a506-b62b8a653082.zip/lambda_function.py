import json
import psycopg2
import datetime

def lambda_handler(event, context):
    
    conn = psycopg2.connect(
        database="3B-CDXP",
        user="mauticanalytics",
        password="Mvkor!kens",
        host="analytics-mautics.chxqqwn3nfwz.us-east-2.rds.amazonaws.com",
        port='5432'
    )

    cur1 = conn.cursor()
        
    for i in event:
        row = i['data']
        
        client_id = row[0]
        event_nk = row[1]
        event_date = None if row[2] == None else datetime.datetime.strptime(row[2], "%Y-%m-%d").date()
        event_type = row[3]
        event_properties = {
            "CustomerNumber": row[4],
            "FirstName": row[5],
            "LastName": row[6],
            "Address": row[7],
            "ZIPCode": row[8],
            "EmailAddress": row[9],
            "EmailDomain": row[10],
            
            "VIN": row[11],
            "Make": row[12],
            "Model": row[13],
            "Year": row[14],
            "Type": row[15],
            
            "AppointmentDate": row[16],
            "AppointmentTime": row[17],
            "AppointmentCreateDate": row[18],
            "RONumber": row[19],
            "LastROMiles": row[20],
            "LastRODate": row[21],
            "PromiseDate": row[22],
            "PromiseTime": row[23],
            "Cause": row[24],
            "Complaint": row[25],
            "Comment": row[26],
            "OperationCode": row[27],
            "OperationCodeDescription": row[28],
            "RecommendedOperationCode": row[29],
            "RecommendedOperationCodeDescription": row[30],
            "ServiceAdvisorName": row[31],
            "ServiceAdvisorNumber": row[32],
            "SaleType": row[33],
            "WaitingFlag": row[34],
            "LoanerFlag": row[35],
            "AlternateTransportation": row[36],
            "EstimateTime": row[37],
            "EstimateAmount": row[38],
            "TagNumber": row[39],
            "ModelNumber": row[40],
            "AppointmentMileage": row[41],
            "Description": row[42],
            
            "ExteriorColor": row[43],
            "StockNumber": row[44],
            "Transmission": row[45],
            "Trim": row[46],
            "LicensePlateNumber": row[47],
            "DeliveryDate": row[48],
            "DeliveryMileage": row[49],
            "InServiceDate": row[50],
            
            "VINExplosionYear": row[51],
            "VINExplosionMake": row[52],
            "VINExplosionModel": row[53],
            "VINExplosionTrim": row[54],
            "VINExplosionTransmissionType": row[55],
            "VINExplosionFuelType": row[56],
            "VINExplosionEngineSize": row[57],
            "VINExplosionGVWRange": row[58],
            
            "HomePhone": row[59],
            "CellPhone": row[60],
            "WorkPhone": row[61],
            "BirthDate": row[62],
            
            "IndividualBusinessFlag": row[63],
            "OptOut": row[64],
            "BlockEmail": row[65],
            "BlockMail": row[66],
            "BlockPhone": row[67],
            "CustomerCreateDate": row[68],
            "CustomerLastActivityDate": row[69]
        }
        
        ##############
        
        query1 = f"""
            CALL marketing.upsert_event(
                %s, %s, %s, %s, %s
            )
            """
        
        cur1.execute(query1, (client_id, event_nk, event_date, event_type, json.dumps(event_properties)))

        conn.commit()
    
    conn.close()
    
    return {
        'statusCode': 200
    }
