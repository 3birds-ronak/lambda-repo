import psycopg2
import json
import boto3
import requests
import datetime
client = boto3.client('lambda', region_name='us-east-2')

def lambda_handler(event, context):
    
    conn = None
    try:
        conn = psycopg2.connect(
            database="3B-CDXP",
            user="mauticanalytics",
            password="Mvkor!kens",
            host="analytics-mautics.chxqqwn3nfwz.us-east-2.rds.amazonaws.com",
            port='5432'
        )
    
        cur = conn.cursor()
    
        query1 = f"""
            SELECT c.campaign_id, c.campaign_source_id, i.instance_data, i.instance_id, c.client_id
            FROM marketing.campaign c
            JOIN marketing.instance i on i.instance_id = c.instance_id AND i.instance_type = 'Mautic'
            -- WHERE c.campaign_source_id = 38
            """
        cur.execute(query1)
    
        for row in cur:
            campaign_id = row[0]
            campaign_source_id = row[1]
            instance_id = row[3]
            client_id = row[4]
            is_contact_exist = True
            contact_start = 0
            
            while is_contact_exist == True:
                
                r = requests.get(row[2]['instance_url'] + "/api/campaigns/" + str(campaign_source_id) + "/contacts?start=" + str(contact_start) + "&limit=1000", auth=(row[2]['admin_username'], row[2]['admin_password']))
                json_contact = r.json()
                
                if r.status_code == 200 and len(json_contact['contacts']) > 0:
                    contact_start = contact_start + 1000
                    
                    for contact in json_contact['contacts']:
                        contact_source_id = contact['lead_id']
                        created = contact['date_added']
                        
                        res = client.invoke(
                            FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:3B-CDXP_Contact_Build_P2',
                            InvocationType = 'Event',
                            Payload = json.dumps({"campaign_id":campaign_id, "campaign_source_id":campaign_source_id, "instance_id":instance_id, "client_id":client_id, "contact_source_id":contact_source_id, "created":created, "instance_url":row[2]['instance_url'], "admin_username":row[2]['admin_username'], "admin_password":row[2]['admin_password']})
                        )
                else :
                    is_contact_exist = False
        
    except Exception as e:
        print('Error', e)
        raise e
    finally:
        if conn is not None:
            print('Inside Conn', conn)
            conn.close()
            print('conn closed', conn)
        print('Finally End')

    return {
        'statusCode': 200,
        'body': 'Success'
    }

if __name__ == "__main__":
    lambda_handler('', '')