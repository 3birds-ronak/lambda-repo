import json
import pyodbc
import boto3
client = boto3.client('lambda', region_name='us-east-2')

def lambda_handler(event, context):
    server = '10.254.210.32' 
    database = 'EDW_target' 
    username = 'helium' 
    password = 'heliumpw' 
    clientid = event['client_id']
    #clientid = 173033
    
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    cur = conn.cursor()
    cur.execute(f"""
        SELECT --TOP 10
            p.ClientID as client_id
            ,p.PageViewID as event_nk 
            ,CAST(p.ViewDateTime AS DATE) as event_date
            ,'pageview' as event_type
        
            ,p.RecipientID
            ,r.FirstName
            ,r.LastName
            ,r.Address1
            ,r.Address2
            ,r.City
            ,r.[State]
            ,r.Country
            ,r.ZipCode
            ,r.EmailAddress
            ,r.EmailDomain
            ,r.CellPhone
            ,r.WorkPhone
            ,r.HomePhone
        
            ,[HostName]
            ,[Medium]
            ,[Campaign]
            ,[SendRequestID]
            ,[PagePath]
            ,[PreviousPagePath]
            ,[IsLandingPage]
            ,[InteractionOrder]
            ,[ViewMinutes]
            ,[IsInventory]
            ,[IsVehicle]
            ,[IsModel]
            ,[IsDetail]
            ,[IsVIN]
            ,[IsCPO]
            ,[IsSearchNew]
            ,[IsSearchUsed]
            ,[IsService]
            ,[IsParts]
            ,[IsCoupon]
            ,[IsSpecials]
            ,[IsOffer]
            ,[IsFeature]
            ,[IsIncentive]
            ,[IsLease]
            ,[IsFinance]
            ,[IsTrade]
            ,[IsQuote]
            ,[IsMap]
            ,[IsDirections]
            ,[IsSchedule]
            ,[IsContact]
        FROM GA_PageViews p
            INNER JOIN [dbo].[Email_Recipients] r  with (nolock, readuncommitted) on
        		r.ClientID = p.ClientID AND r.RecipientID = p.RecipientID
        WHERE p.RecipientID IS NOT NULL AND p.ClientID = {clientid}

        """
    )
    
    array_msg_body = []
    counter = 0
    
    for row in cur:
        row[2] = None if row[2] == None else str(row[2])
    
        msg_body = {
        	"data": list(row)
        }
        
        array_msg_body.append(msg_body)
        counter += 1
        
        if counter % 50 == 0:
            res = client.invoke(
                FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:3B-CDXP_GA_Pageview_Sync_P2',
                InvocationType = 'Event',
                Payload = json.dumps(array_msg_body)
            )
            counter = 0
            array_msg_body = []
    
    if len(array_msg_body) > 0:
        res = client.invoke(
            FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:3B-CDXP_GA_Pageview_Sync_P2',
            InvocationType = 'Event',
            Payload = json.dumps(array_msg_body)
        )
        
    conn.close()
    
    return {
        'statusCode': 200
    }
        
    
    
