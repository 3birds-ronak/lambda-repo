import json
import pyodbc
import boto3

client = boto3.client('lambda')

def lambda_handler(event, context):
    
    session = boto3.Session()

    sqs_client = session.client(
        service_name='sqs',
        endpoint_url='https://sqs.us-east-2.amazonaws.com',
    )
    sqs_queue_url = sqs_client.get_queue_url(QueueName='mautic_create_contact_queue')['QueueUrl']
    
    ###########
    
    server = '10.254.210.32' 
    database = 'EDW_target' 
    username = 'helium' 
    password = 'heliumpw' 
    
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    #print('connect succ')
    cursor = conn.cursor()
    cursor.execute('select top 5 c.FirstName, c.LastName, c.EmailAddress, c.Address1, c.Address2, c.City, c.State, c.ZipCode, c.LastActivityDate,  c.ClientID, c.RecipientID, c.EDW_DMS_Customer_ID, c.LeadStatusType, c.ContactType, c.Sales_Last_VehicleType, c.Sales_Last_DealType, c.LastVehicleMake, c.LastVehicleModel, c.LastVehicleYear, c.OwnedVehicleBodyStyle, c.ContractEndDate, c.WarrantyEndDate, c.Sales_Last_LeaseEndDate, c.EstimatedVehicleMileage, c.LastTransactionDate, c.Sales_Last_Date, c.Service_Last_Date, c.Service_Last_DeclinedDate, c.NextServiceAppt, c.EquityValueRough, c.EquityValueAverage, c.EquityValueClean, c.LeaseEndForecastMileagePenalty, c.LeaseEndMileage, c.Service_Next_ServiceMileage, c.Service_Next_ServiceType, c."3BirdsDesiredVehicleType", c."3BirdsDesiredVehicleMake", c."3BirdsDesiredVehicleModel", c."3BirdsDesiredVehicleYear", c."3BirdsDesiredVehicleBodyStyle", c.CurrentBalance, c.CurrentValue, c.IsUpcomingService, c.Service_Last_Department, c.SalesPerson, c.SalesPersonEmail, c.MonthlyPayments from CVH c where c.clientid = 173033')
    
    for row in cursor:
        print('inside for loop')
        msg_body = {
           "FirstName": row[0],
           "LastName": row[1],
           "EmailAddress": row[2],
           "Address1": row[3],
           "Address2": row[4],
           "City": row[5],
           "State": row[6],
           "ZipCode": row[7],
           "LastActivityDate": None if row[8] == None else str(row[8]),
           "ClientID": row[9],
           "RecipientID": row[10],
           "EDW_DMS_Customer_ID": row[11],
           "LeadStatusType": row[12],
           "ContactType": row[13],
           "Sales_Last_VehicleType": row[14],
           "Sales_Last_DealType": row[15],
           "LastVehicleMake": row[16],
           "LastVehicleModel": row[17],
           "LastVehicleYear": row[18],
           "OwnedVehicleBodyStyle": row[19],
           "ContractEndDate": None if row[20] == None else str(row[20]),
           "WarrantyEndDate": None if row[21] == None else str(row[21]),
           "Sales_Last_LeaseEndDate": None if row[22] == None else str(row[22]),
           "EstimatedVehicleMileage": None if row[23] == None else float(row[23]),
           "LastTransactionDate": None if row[24] == None else str(row[24]),
           "Sales_Last_Date": None if row[25] == None else str(row[25]),
           "Service_Last_Date": None if row[26] == None else str(row[26]),
           "Service_Last_DeclinedDate": None if row[27] == None else str(row[27]),
           "NextServiceAppt": None if row[28] == None else str(row[28]),
           "EquityValueRough": None if row[29] == None else float(row[29]),
           "EquityValueAverage": None if row[30] == None else float(row[30]),
           "EquityValueClean": None if row[31] == None else float(row[31]),
           "LeaseEndForecastMileagePenalty": None if row[32] == None else float(row[32]),
           "LeaseEndMileage": None if row[33] == None else float(row[33]),
           "Service_Next_ServiceMileage": None if row[34] == None else float(row[34]),
           "Service_Next_ServiceType": row[35],
           "3BirdsDesiredVehicleType": row[36],
           "3BirdsDesiredVehicleMake": row[37],
           "3BirdsDesiredVehicleModel": row[38],
           "3BirdsDesiredVehicleYear": row[39],
           "3BirdsDesiredVehicleBodyStyle": row[40],
           "CurrentBalance": None if row[41] == None else float(row[41]),
           "CurrentValue": None if row[42] == None else float(row[42]),
           "IsUpcomingService": row[43],
           "Service_Last_Department": row[44],
           "SalesPerson": row[45],
           "SalesPersonEmail": row[46],
           "MonthlyPayments": None if row[47] == None else float(row[47])
        }
        print(msg_body)
        sqs_client.send_message(
            QueueUrl = sqs_queue_url,
            MessageBody = json.dumps(msg_body),
        )
        
    conn.close()
    
    return {
        'statusCode': 200
    }
        
    
    
