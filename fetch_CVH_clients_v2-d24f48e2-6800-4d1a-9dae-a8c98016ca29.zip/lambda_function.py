import json
import pyodbc
import boto3
client = boto3.client('lambda', region_name='us-east-2')

def lambda_handler(event, context):
    server = '10.254.210.32' 
    database = 'EDW_target' 
    username = 'helium' 
    password = 'heliumpw' 
    clientid = event['client_id']
    is_simulator = event['is_simulator']
    #clientid = 173033
    #is_simulator = 1

    
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    cur = conn.cursor()
    cur.execute(f"""
        SELECT m.mautic_contact_id, t.*, CONVERT(VARCHAR(255), t.CustomerHashKey, 1) AS CustomerHashKey_var FROM (
            SELECT c.ClientID, c.EDW_DMS_Customer_ID, c.RecipientID
                , c.FirstName, c.LastName, c.EmailAddress, c.Address1, c.Address2, c.City, c.State, c.ZipCode
                , c.LastActivityDate, c.ContactType, c.LeadStatusType
                , c.Sales_Last_VehicleType, c.Sales_Last_DealType, c.LastVehicleMake, c.LastVehicleModel, c.LastVehicleYear, c.OwnedVehicleBodyStyle
                , c.ContractEndDate, c.WarrantyEndDate, c.Sales_Last_LeaseEndDate, c.EstimatedVehicleMileage, c.LastTransactionDate
                , c.Sales_Last_Date, c.Service_Last_Date, c.Service_Last_DeclinedDate, c.NextServiceAppt
                , c.EquityValueRough, c.EquityValueAverage, c.EquityValueClean, c.LeaseEndForecastMileagePenalty, c.LeaseEndMileage, c.Service_Next_ServiceMileage, c.Service_Next_ServiceType
                , c."3BirdsDesiredVehicleType", c."3BirdsDesiredVehicleMake", c."3BirdsDesiredVehicleModel", c."3BirdsDesiredVehicleYear", c."3BirdsDesiredVehicleBodyStyle"
                , c.CurrentBalance, c.CurrentValue, c.Service_Last_Department, c.SalesPerson, c.SalesPersonEmail, c.MonthlyPayments
                , c.LastOpenDate, c.LastClickDate, c.Sales_First_Date, c.Service_First_Date, c.LeadCreateDate, c.IsUnsubscribed
                , c.LoyaltyAccruedPoints, c.LoyaltyAccruedValue, c.LoyaltyAccruedDate, m.GroupId
                , c.CustomerHashKey
                , c."3BirdsDesiredVehicleTrim", c."3BirdsDesiredVehicleInventory"
                , c.Service_Last_Declined1, c.Service_Last_Declined2, c.Service_Last_Declined3, c.Service_Last_Declined4, c.Service_Last_Declined5
                , c.AvgMilesPerDay, c.NextServiceDate
                , c.NLO, c.NLOReason
            FROM EDW_target.dbo.CVH c
            JOIN EDW_target.dbo.Mautic_Instance_Group_Membership m ON m.ClientID = c.ClientID
            WHERE c.ClientID = {clientid} AND c.CustomerHashKey IS NOT NULL -- AND c.EDW_DMS_Customer_ID = -17045016
            EXCEPT
            SELECT m.client_id, m.dms_customer_id, m.customer_id
                , m.firstname, m.lastname, m.email, m.address1, m.address2, m.city, m.[state], m.zipcode
                , m.last_active, m.contact_type, m.lead_status
                , m.[purchase_condition], m.[purchase_type], m.[make], m.[model], m.[year], m.[type]
                , m.[contract_end], m.[warranty_end], m.[lease_end], m.[estimated_mileage], m.[last_transaction]
                , m.[last_purchase], m.[last_service], m.[last_service_declined], m.[next_appt]
                , m.[equity_rough], m.[equity_avg], m.[equity_clean], m.[lease_end_penalty_estimate], m.[lease_end_mileage_estimate], m.[next_service_miles], m.[next_service_interval]
                , m.[desired_condition], m.[desired_make], m.[desired_model], m.[desired_year], m.[desired_type]
                , m.[loyalty_balance], m.[loyalty_value], m.[last_service_dept], m.[sales_person], m.[sales_person_email], m.[monthly_payment]
                , m.[last_email_open], m.[last_email_click], m.[first_purchase], m.[first_service], m.[last_lead], m.[eligible_email]
                , m.[loyalty_accrued_points], m.[loyalty_accrued_value], m.[loyalty_accrued], m.GroupID
                , m.CustomerHashKey
                , m.[desired_trim], m.[desired_inventory]
                , m.[service_last_declined1], m.[service_last_declined2], m.[service_last_declined3], m.[service_last_declined4], m.[service_last_declined5]
                , m.[avg_miles_perday], m.[next_service_date]
                , m.[is_nlo], m.[nlo_reason]
            FROM EDW_target.dbo.Mautic_Contact_Mapping m
            WHERE m.client_id = {clientid} AND m.is_simulator = {is_simulator} -- AND m.dms_customer_id = -17045016
        ) t
        LEFT JOIN Mautic_Contact_Mapping m ON m.CustomerHashKey = t.CustomerHashKey AND m.is_simulator = {is_simulator}"""
    )
    
    array_msg_body = []
    counter = 0
    for row in cur:
        row[12] = None if row[12] == None else str(row[12])
        row[21] = None if row[21] == None else str(row[21])
        row[22] = None if row[22] == None else str(row[22])
        row[23] = None if row[23] == None else str(row[23])
        row[25] = None if row[25] == None else str(row[25])
        row[26] = None if row[26] == None else str(row[26])
        row[27] = None if row[27] == None else str(row[27])
        row[28] = None if row[28] == None else str(row[28])
        row[29] = None if row[29] == None else str(row[29])
        row[48] = None if row[48] == None else str(row[48])
        row[49] = None if row[49] == None else str(row[49])
        row[50] = None if row[50] == None else str(row[50])
        row[51] = None if row[51] == None else str(row[51])
        row[52] = None if row[52] == None else str(row[52])
        row[56] = None if row[56] == None else str(row[56])
        row[67] = None if row[67] == None else str(row[67])
        
        row[24] = None if row[24] == None else float(row[24])
        row[30] = None if row[30] == None else float(row[30])
        row[31] = None if row[31] == None else float(row[31])
        row[32] = None if row[32] == None else float(row[32])
        row[33] = None if row[33] == None else float(row[33])
        row[34] = None if row[34] == None else float(row[34])
        row[35] = None if row[35] == None else float(row[35])
        row[42] = None if row[42] == None else float(row[42])
        row[43] = None if row[43] == None else float(row[43])
        row[47] = None if row[47] == None else float(row[47])
        row[54] = None if row[54] == None else float(row[54])
        row[55] = None if row[55] == None else float(row[55])
        row[66] = None if row[66] == None else float(row[66])
        
        row[58] = None
        
        msg_body = {
        	"data": list(row)
        }
        
        array_msg_body.append(msg_body)
        counter += 1
        
        if counter % 50 == 0:
            res = client.invoke(
                FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:send_payload_sqs_v2',
                InvocationType = 'Event',
                Payload = json.dumps(array_msg_body)
            )
            counter = 0
            array_msg_body = []
    
    if len(array_msg_body) > 0:
        res = client.invoke(
            FunctionName = 'arn:aws:lambda:us-east-2:570277181188:function:send_payload_sqs_v2',
            InvocationType = 'Event',
            Payload = json.dumps(array_msg_body)
        )
        
    conn.close()
    
    return {
        'statusCode': 200
    }
        
    
    
